# AUDIS OS — Design System Handoff

Use este prompt para que outra IA continue o redesign aplicando exatamente a mesma linguagem visual.

---

## CONTEXTO

Você está continuando o redesign da **AUDIS** — SaaS de gestão para agências de marketing criativo. As telas-base já foram redesenhadas (Login, Cockpit, Agenda, Tráfego, Financeiro, Pessoas, Brand Kit, Portal do Cliente). Sua missão: aplicar o mesmo design system nas telas que ainda faltam (Operações, Funil, Estoque, Conteúdo, Social, Solicitações, Entregas, Projetos, Equipe, Aprendizado).

**Personalidade da marca:** Confiável e estável. Agência criativa, mas SaaS profissional. Inspiração: Linear, Stripe, Mercury.

**Stack técnico:** HTML + React 18 (via Babel inline) + Vanilla CSS (sem Tailwind). Single Page App com roteamento por estado (`activeNav`).

---

## DESIGN SYSTEM — TOKENS (já definidos em `styles.css`)

### Cores
```css
--primary: #6D28D9;          /* Roxo AUDIS (refinado) */
--primary-600: #5B21B6;
--primary-700: #4C1D95;
--primary-100: #EDE9FE;      /* tint suave */
--primary-200: #DDD6FE;

--bg: #FAFAF9;               /* fundo da página */
--surface: #FFFFFF;          /* fundo de cards */
--surface-soft: #F5F5F4;     /* card flat / hover */
--surface-inset: #F8F8F7;

--border: #E7E5E4;
--border-soft: #EFEDEB;
--border-strong: #D6D3D1;
--divider: #EFEDEB;

--text: #0C0A09;             /* texto principal */
--text-secondary: #44403C;
--text-muted: #78716C;       /* labels, meta */
--text-subtle: #A8A29E;
--text-disabled: #D6D3D1;

/* Status — sempre em par bg + cor */
--success: #16A34A; --success-bg: #F0FDF4;
--warning: #B45309; --warning-bg: #FFFBEB;
--danger:  #B91C1C; --danger-bg:  #FEF2F2;
--info:    #1D4ED8; --info-bg:    #EFF6FF;
```

Dark mode existe (via `[data-theme="dark"]`). Sempre use as CSS vars, nunca hardcode.

### Tipografia
- **Display + Body:** `General Sans` (Fontshare — humanista geométrica)
- **Mono:** `Geist Mono` (dados numéricos, horários, valores)
- **Importar:**
  ```html
  <link href="https://api.fontshare.com/v2/css?f[]=general-sans@400,500,600,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Geist+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  ```
- Tracking: títulos `-0.018em`, body `-0.008em`
- Pesos: 500 (medium UI), 600 (display/título), 700 (ênfase)

### Espaçamento (variáveis CSS)
```css
--pad-card: 20px;      --pad-card-y: 18px;
--gap-grid: 16px;      --gap-stack: 14px;
--row-h: 38px;
--radius: 10px;        --radius-sm: 8px;        --radius-lg: 14px;
--header-h: 60px;      --sidebar-w: 64px;       --sidebar-w-open: 232px;
```

### Geometria
- Cards: `border-radius: 10px`, borda `1px solid var(--border)` (estilo padrão "bordered")
- Botões: `border-radius: 8px`, altura 36px (sm: 30px), padding `0 14px`
- Pills/badges: `border-radius: 999px`

---

## COMPONENTES — PATTERNS CANÔNICOS

### Card básico
```html
<div class="card">
  <div class="card-head">
    <div class="card-title-group">
      <div class="card-title">Título</div>
      <div class="card-sub">Subtítulo descritivo</div>
    </div>
    <div class="card-actions">
      <a class="link">Ver tudo →</a>
    </div>
  </div>
  <div class="card-body">
    <!-- conteúdo -->
  </div>
  <div class="card-foot">
    <!-- opcional -->
  </div>
</div>
```

### KPI card (com sparkline opcional)
```jsx
<div className="kpi">
  <div className="kpi-head">
    <span className="kpi-label">CLIENTES ATIVOS</span>
    <div className="kpi-icon">{icon}</div>
  </div>
  <div className="kpi-value">18</div>
  <div className="kpi-meta">
    <span className="delta up">{arrowUpIcon} +2</span>
    <span>vs. mês passado</span>
  </div>
</div>
```

Use `.big-stat` quando o valor é o protagonista (Tráfego, Financeiro). Suporta variantes `.is-dark` (fundo preto) e `.is-emphasis` (gradiente roxo).

### Badges de status
```html
<span class="badge badge-success"><span class="dot"></span>em dia</span>
<span class="badge badge-warning"><span class="dot"></span>pendente</span>
<span class="badge badge-primary">Visual QG</span>
<span class="badge badge-neutral">Categoria</span>
```

### Tabs (sub-nav)
```jsx
<div className="tabs">
  <button className="tab is-active">Visão geral</button>
  <button className="tab">Estratégia <span className="tab-count">8</span></button>
</div>
```

### Botões
```html
<button class="btn btn-primary">{icon} Ação principal</button>
<button class="btn btn-secondary">Ação secundária</button>
<button class="btn btn-ghost">Ação terciária</button>
<button class="btn btn-primary btn-sm">Pequeno</button>
```

### Tabela
```html
<table class="table">
  <thead><tr><th>Nome</th><th class="right">Valor</th></tr></thead>
  <tbody>
    <tr><td><strong>Nome</strong></td><td class="right num">R$ 1.200</td></tr>
  </tbody>
</table>
```

### Linha de lista (Pessoas, Solicitações, Entregas, Projetos)
```html
<div class="list-row client-row">
  <div class="av" style="background: linear-gradient(135deg, ...)">XX</div>
  <div>
    <div class="name">Nome do Cliente <span class="badge badge-success"><span class="dot"></span>ativo</span></div>
    <div class="meta">e-mail · gestor · meta</div>
  </div>
  <div class="mono">R$ 1.200</div>
  <div class="actions">
    <button class="btn btn-secondary btn-sm">Ação</button>
  </div>
</div>
```

### Filter bar (acima de listas/grids)
```html
<div class="filter-bar">
  <div class="left">
    <div class="tabs"><!-- chips de filtro --></div>
  </div>
  <div class="right">
    <div class="search"><!-- busca --></div>
    <div class="tabs"><!-- toggle list/grid --></div>
  </div>
</div>
```

### Banner de alerta
```html
<div class="banner warning">
  {icon}
  <span class="grow"><b>Saldo baixo.</b> Texto explicativo</span>
  <button class="banner-action">Ação</button>
</div>
```
Variantes: `.success`, `.warning`, `.danger`, `.info`.

### Empty state
```html
<div class="empty-view">
  <div class="icon-bg">{icon}</div>
  <h3>Título do estado vazio</h3>
  <p>Texto explicativo claro</p>
  <button class="btn btn-primary btn-sm">CTA principal</button>
</div>
```

### Avatars (clientes/equipe)
- Círculo com gradiente colorido + iniciais
- Tamanhos: 18px (timeline), 28px (sidebar), 38px (lista), 64px (banner)
- Cores aleatórias mas consistentes por entidade. Paleta sugerida:
  ```js
  'linear-gradient(135deg,#FCA5A5,#E11D48)' // rosa-vermelho
  'linear-gradient(135deg,#A78BFA,#6D28D9)' // roxo
  'linear-gradient(135deg,#5EEAD4,#0F766E)' // teal
  'linear-gradient(135deg,#FCD34D,#B45309)' // âmbar
  'linear-gradient(135deg,#93C5FD,#1D4ED8)' // azul
  'linear-gradient(135deg,#34D399,#10B981)' // verde
  ```

### Sparklines (KPI)
SVG inline com `viewBox="0 0 90 38"`, gradient + path. Ver `Sparkline` em `cockpit.jsx`.

### Charts simples
- **Line:** SVG com path manual (ver `LineChart` em `views/trafego.jsx`)
- **Donut:** SVG com `stroke-dasharray` para segmentos (ver `DonutChart`)
- **Bars:** retângulos com `rx="3"` (ver `MonthBars` em `views/financeiro.jsx`)
- Sempre incluir grid horizontal pontilhado e labels mono

---

## ESTRUTURA DE UMA VIEW NOVA

Cada tela vai em `views/<nome>.jsx` e segue este esqueleto:

```jsx
// views/operacoes.jsx
const { useState: useOpState } = React;

const OP_ICONS = {
  // ícones lucide-style inline (16-18px, stroke 2, linecap round)
  icon1: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">...</svg>,
};

const MOCK_DATA = [
  // dados realistas em pt-BR (R$, nomes brasileiros, datas BR)
];

function Operacoes() {
  const [tab, setTab] = useOpState('overview');
  return (
    <div className="page-body view-enter">
      <div className="page-header">
        <div className="page-title-group">
          <div className="page-eyebrow"><span>Operação</span></div>
          <h1 className="page-title">Título da tela</h1>
          <p className="page-sub">Descrição da tela em 1 linha</p>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary">Secundário</button>
          <button className="btn btn-primary">{plusIcon} Ação primária</button>
        </div>
      </div>

      {/* Tabs opcionais */}
      <div className="page-tabs-row">
        <div className="tabs">...</div>
      </div>

      {/* KPIs ou cards principais */}
      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat">...</div>
      </div>

      {/* Layout principal: 2 colunas com grid-template-columns */}
      <div className="grid" style={{gridTemplateColumns:'minmax(0,2fr) minmax(0,1fr)', marginTop:'var(--gap-grid)'}}>
        <div className="card">...</div>
        <div className="card">...</div>
      </div>
    </div>
  );
}

Object.assign(window, { Operacoes });
```

Depois adicione no `Cockpit AUDIS.html`:
```html
<script type="text/babel" src="views/operacoes.jsx"></script>
```

E em `app.jsx`:
1. Adicione em `VIEWS_BUILT`: `'operacoes'`
2. Adicione no render condicional: `{activeNav === 'operacoes' && <Operacoes />}`

---

## REGRAS DE OURO (cumpra sempre)

1. **Nada de dados slop.** Não invente métricas só pra preencher. Cada KPI/card precisa fazer sentido pra aquela tela.

2. **Use as CSS vars.** Nunca hardcode `#6D28D9`. Sempre `var(--primary)`.

3. **Use `General Sans` por padrão.** Display em peso 600 (não 700) para combinar com a marca.

4. **Hierarquia de informação clara:**
   - Eyebrow (uppercase, 11px, muted)
   - Título (28-30px, peso 600)
   - Subtítulo (13.5px, muted)
   - Body (14px)
   - Meta (12px, muted)

5. **Tabular nums em qualquer número** (`font-variant-numeric: tabular-nums`).

6. **Dados em mono** (horários, valores em R$, IDs). Use a classe `.mono` ou `.num`.

7. **Status semáforo:** verde = bom, âmbar = atenção, vermelho = crítico, azul = informação, neutro = sem peso.

8. **Sem ícones inúteis.** Cada ícone deve ajudar a escanear. Cabeçalho de card pode dispensar ícone.

9. **Avatares com gradiente colorido.** Nunca placeholder cinza.

10. **Mock data em pt-BR.** Nomes brasileiros, R$ formatado (`R$ 1.200,00`), datas DD/MM, telefones BR.

11. **Empty states sempre acionáveis.** Não deixe só "Nenhum dado". Mostre o que fazer.

12. **Hover states em tudo clicável.** `background: var(--surface-soft)` para hover sutil.

13. **Tema escuro:** os tokens já invertem. Teste com `[data-theme="dark"]` antes de entregar.

14. **Densidade variável:** Use `var(--pad-card)`, `var(--gap-grid)` — eles mudam quando o usuário troca a densidade no Tweaks.

---

## TELAS PENDENTES — SUGESTÕES DE CONTEÚDO

### Operações
Visão de tarefas em formato Kanban ou lista por status. Coluna por estado: Backlog / Em andamento / Em revisão / Concluído. Filtrar por cliente, responsável, prazo.

### Funil
Pipeline de vendas. Colunas: Lead → Qualificado → Proposta → Negociação → Fechado. Cards arrastáveis (visual) com valor, cliente, próximo passo.

### Estoque
Materiais físicos (brindes, kits, mockups). Lista de itens com quantidade, custo unitário, alerta de baixo estoque, último uso.

### Conteúdo
Calendário editorial. Cards de posts/artes/roteiros com status (Em ideação / Em produção / Em aprovação / Aprovado / Publicado). Visão por cliente e por canal.

### Social
Cronograma de posts por rede. Calendário/feed por canal (Instagram, TikTok, LinkedIn). Performance de cada post.

### Solicitações
Caixa de entrada das demandas dos clientes. Lista de pedidos com prioridade, prazo, status, último update. Como Helpscout/Linear.

### Entregas
Pasta de arquivos finais por cliente. Grid de entregas (vídeos, artes, roteiros) com preview, data, status de aprovação.

### Projetos
Projetos especiais/grandes (campanhas, lançamentos). Tipo Notion/Asana: timeline, escopo, equipe, milestones.

### Equipe
Gestão da equipe interna. Lista de pessoas, papéis, horas trabalhadas, projetos ativos, performance. Similar a Pessoas mas para equipe.

### Aprendizado
Tutoriais e onboarding. Lista de cursos/vídeos com progresso, tempo restante, certificados.

---

## ARQUIVOS QUE EXISTEM (NÃO MEXA)

- `styles.css` — design tokens + componentes base
- `views.css` — componentes extras (tabs, calendar, charts, tables, etc.)
- `cockpit.jsx` — Sidebar, Topbar, Logo, Cockpit page, QuickAddDrawer
- `app.jsx` — roteamento, tweaks, estado global
- `tweaks-panel.jsx` — não edite
- `views/agenda.jsx`, `views/trafego.jsx`, `views/financeiro.jsx`, `views/pessoas.jsx`, `views/brandkit.jsx`, `views/portal.jsx`

## ARQUIVOS PARA CRIAR

- `views/operacoes.jsx`, `views/funil.jsx`, `views/estoque.jsx`, etc.
- Adicione cada um ao `Cockpit AUDIS.html` e `app.jsx`.

---

## CHECKLIST FINAL DE CADA TELA

- [ ] Page header com eyebrow + title + sub + actions
- [ ] KPIs ou highlights no topo (se aplicável)
- [ ] Layout em grid de 1, 2 ou 3 colunas
- [ ] Pelo menos uma interação (filtro, tab, search)
- [ ] Mock data realista em pt-BR
- [ ] Hover states funcionando
- [ ] Empty state desenhado (mesmo que invisível em dados de teste)
- [ ] Testado em light + dark
- [ ] Sem console errors
- [ ] Mesma personalidade tipográfica das outras telas

---

**Pronto. Mantenha a coerência. Quando em dúvida, abra `views/trafego.jsx` ou `views/financeiro.jsx` — são as telas com mais densidade e melhor referência de aplicação do system.**
