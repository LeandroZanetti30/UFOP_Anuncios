// cockpit.jsx — Página Cockpit modernizada (AUDIS OS)
// Componentes principais + ícones inline (lucide-style)

const { useState, useEffect, useRef, useMemo, useCallback } = React;

/* ──────────────────────────────────────────────────────────
   ICONS — lucide-style simple line icons
   ────────────────────────────────────────────────────────── */
const I = {
  menu:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="14" y2="17"/></svg>,
  home:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>,
  calendar:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="16" y1="2" x2="16" y2="6"/></svg>,
  target:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></svg>,
  funnel:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="3 4 21 4 14 13 14 20 10 22 10 13 3 4"/></svg>,
  package:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><line x1="12" y1="13" x2="12" y2="21"/></svg>,
  trending:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 17 9 11 13 15 21 7"/><polyline points="14 7 21 7 21 14"/></svg>,
  zap:       <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 4 14 11 14 9 22 20 10 13 10 13 2"/></svg>,
  share:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/></svg>,
  users:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  message:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-4-1L3 21l1.5-5.5A8.38 8.38 0 0 1 3 11.5a8.5 8.5 0 0 1 8.5-8.5 8.38 8.38 0 0 1 8.5 8.5z"/></svg>,
  folder:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>,
  film:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="7" y1="3" x2="7" y2="21"/><line x1="17" y1="3" x2="17" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/></svg>,
  dollar:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>,
  userCog:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="7" r="4"/><path d="M2 21v-2a4 4 0 0 1 4-4h4"/><circle cx="18" cy="15" r="2.5"/><path d="M18 11v1.5M18 17.5V19M21.5 15H20M16 15h-1.5M20.6 12.5l-1 1M16.4 17l-1 1M20.6 17.5l-1-1M16.4 13l-1-1"/></svg>,
  book:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>,
  bell:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>,
  search:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></svg>,
  plus:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  arrowUp:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 10 12 4 18 10"/><line x1="12" y1="4" x2="12" y2="19"/></svg>,
  arrowDn:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="18 14 12 20 6 14"/><line x1="12" y1="5" x2="12" y2="20"/></svg>,
  arrowRt:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>,
  chevRt:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 6 15 12 9 18"/></svg>,
  clock:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>,
  videoCam:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>,
  paperclip: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.4 11l-9.2 9.2a5.4 5.4 0 0 1-7.6-7.6L13 4.2a3.6 3.6 0 1 1 5 5L9.8 17.4a1.8 1.8 0 1 1-2.6-2.6L15 7"/></svg>,
  alert:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.3 3.86 1.82 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.86a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><circle cx="12" cy="17" r="1" fill="currentColor"/></svg>,
  info:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="17"/><circle cx="12" cy="8" r="1" fill="currentColor"/></svg>,
  check:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="5 12 10 17 19 7"/></svg>,
  moon:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>,
  sun:       <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="20" x2="12" y2="22"/><line x1="4.9" y1="4.9" x2="6.3" y2="6.3"/><line x1="17.7" y1="17.7" x2="19.1" y2="19.1"/><line x1="2" y1="12" x2="4" y2="12"/><line x1="20" y1="12" x2="22" y2="12"/><line x1="4.9" y1="19.1" x2="6.3" y2="17.7"/><line x1="17.7" y1="6.3" x2="19.1" y2="4.9"/></svg>,
  x:         <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>,
  externalLink: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 4h6v6"/><path d="M10 14L20 4"/><path d="M20 14v6H4V4h6"/></svg>,
  brand:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2.5S5 10 5 14a7 7 0 0 0 14 0c0-4-7-11.5-7-11.5z"/></svg>,
  layout:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>,
  pin:       <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14l-1.7-3.4A2 2 0 0 1 17 12.7V7h.5a1 1 0 0 0 0-2h-11a1 1 0 0 0 0 2H7v5.7c0 .31-.07.62-.21.9L5 17z"/></svg>,
};

/* ──────────────────────────────────────────────────────────
   LOGO
   ────────────────────────────────────────────────────────── */
function Logo({ onMarkClick }) {
  return (
    <img
      className="logo-wordmark"
      src="assets/audis-logo.png"
      alt="audis"
      onClick={onMarkClick}
    />
  );
}

/* ──────────────────────────────────────────────────────────
   SIDEBAR — fixed left, below the 60px topbar
   3 modos: expanded / collapsed / hover (expande no hover)
   ────────────────────────────────────────────────────────── */
function Sidebar({ mode, onModeChange, active, onNavigate }) {
  const [showControl, setShowControl] = useState(false);
  const controlRef = useRef(null);

  useEffect(() => {
    if (!showControl) return;
    function onClick(e) {
      if (controlRef.current && !controlRef.current.contains(e.target)) {
        setShowControl(false);
      }
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [showControl]);

  const items = NAV.flatMap(g => g.items);

  return (
    <aside className={`sidebar sb-${mode}`}>
      <nav className="sidebar-nav">
        {items.map(item => {
          const isActive = active === item.id;
          return (
            <div
              key={item.id}
              className={`nav-item ${isActive ? 'is-active' : ''}`}
              onClick={() => onNavigate(item.id)}
              role="button"
              tabIndex={0}
              title={item.label}
            >
              <div className="nav-icon-wrap">
                <span className="nav-icon">{item.icon}</span>
                {item.badge && <span className="nav-icon-badge">{item.badge}</span>}
              </div>
              <div className="nav-label-row">
                <span className="nav-label">{item.label}</span>
                {item.badge && <span className="nav-badge">{item.badge}</span>}
              </div>
            </div>
          );
        })}
      </nav>

      <div className="sidebar-foot" ref={controlRef}>
        {showControl && (
          <div className="sb-control-popover">
            <p className="sb-control-title">Sidebar</p>
            {[
              { id: 'expanded',  label: 'Expandida' },
              { id: 'collapsed', label: 'Recolhida' },
              { id: 'hover',     label: 'Expandir ao passar' },
            ].map(opt => (
              <button
                key={opt.id}
                onClick={() => { onModeChange(opt.id); setShowControl(false); }}
                className="sb-control-item"
              >
                <span className={`sb-radio ${mode === opt.id ? 'is-on' : ''}`}>
                  {mode === opt.id && (
                    <svg viewBox="0 0 12 12" width="8" height="8" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="2.5 6 5 8.5 9.5 3.5"/></svg>
                  )}
                </span>
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        )}
        <button
          onClick={() => setShowControl(v => !v)}
          className={`nav-item sb-control-trigger ${showControl ? 'is-open' : ''}`}
          title="Controle da sidebar"
        >
          <div className="nav-icon-wrap">
            <span className="nav-icon">{I.layout}</span>
          </div>
          <div className="nav-label-row">
            <span className="nav-label">Sidebar</span>
          </div>
        </button>
      </div>
    </aside>
  );
}

/* ──────────────────────────────────────────────────────────
   TOPBAR — fixed top, spans full width (acima da sidebar)
   ────────────────────────────────────────────────────────── */
function Topbar({ dark, onDark, onOpenNotifs, notifsOpen, unread, onOpenDrawer }) {
  return (
    <header className="topbar">
      <div className="topbar-logo">
        <img src="assets/audis-logo.png" alt="Audis" />
      </div>

      <div className="search" onClick={(e) => e.currentTarget.querySelector('input').focus()}>
        <span className="search-icon">{I.search}</span>
        <input placeholder="Buscar cliente, tarefa, projeto…" />
        <span className="kbd">⌘K</span>
      </div>

      <div className="topbar-actions">
        <button className="icon-btn" onClick={onDark} title={dark ? 'Tema claro' : 'Tema escuro'}>
          {dark ? I.sun : I.moon}
        </button>

        <div className="topbar-notif">
          <button className="icon-btn" onClick={onOpenNotifs} title="Notificações">
            {I.bell}
            {unread > 0 && <span className="dot" />}
          </button>
          <NotifsPopover open={notifsOpen} />
        </div>

        <div className="topbar-divider" />

        <div className="avatar" title="Bruno Mendes">BM</div>
      </div>
    </header>
  );
}
const NAV = [
  { group: 'Operação', items: [
    { id: 'inicio',    label: 'Cockpit',    icon: I.home,     badge: '5' },
    { id: 'agenda',    label: 'Agenda',     icon: I.calendar },
    { id: 'operacoes', label: 'Operações',  icon: I.target },
    { id: 'funil',     label: 'Funil',      icon: I.funnel },
    { id: 'estoque',   label: 'Estoque',    icon: I.package },
  ]},
  { group: 'Marketing', items: [
    { id: 'conteudo',  label: 'Conteúdo',   icon: I.zap },
    { id: 'trafego',   label: 'Tráfego',    icon: I.trending },
    { id: 'social',    label: 'Social',     icon: I.share },
  ]},
  { group: 'Clientes', items: [
    { id: 'pessoas',     label: 'Pessoas',      icon: I.users },
    { id: 'solicitacoes',label: 'Solicitações', icon: I.message, badge: '3' },
    { id: 'entregas',    label: 'Entregas',     icon: I.folder },
    { id: 'projetos',    label: 'Projetos',     icon: I.film },
    { id: 'brandkit',    label: 'Brand Kit',    icon: I.brand },
  ]},
  { group: 'Sistema', items: [
    { id: 'financeiro',  label: 'Financeiro',   icon: I.dollar },
    { id: 'equipe',      label: 'Equipe',       icon: I.userCog },
    { id: 'aprendizado', label: 'Aprendizado',  icon: I.book },
  ]},
];

/* ──────────────────────────────────────────────────────────
   NOTIFICATIONS POPOVER
   ────────────────────────────────────────────────────────── */
const NOTIFS = [
  { id: 1, type: 'client', text: <><strong>MP Seminovos</strong> aprovou a entrega de Vídeos · Maio</>, time: 'há 12 min', unread: true, icon: I.check },
  { id: 2, type: 'task',   text: <>Você tem <strong>3 tarefas</strong> com prazo hoje</>, time: 'há 1 h', unread: true, icon: I.clock },
  { id: 3, type: 'team',   text: <><strong>Carla Lopes</strong> comentou em "Roteiro Dia das Mães"</>, time: 'há 2 h', unread: true, icon: I.message },
  { id: 4, type: 'client', text: <>Pagamento de <strong>R$ 1.200</strong> recebido — Estúdio Norte</>, time: 'há 4 h', unread: false, icon: I.dollar },
  { id: 5, type: 'task',   text: <>Campanha "Dia dos Namorados" entra em <strong>lead time</strong> amanhã</>, time: 'ontem', unread: false, icon: I.alert },
];

function NotifsPopover({ open }) {
  return (
    <div className={`popover ${open ? 'open' : ''}`}>
      <div className="popover-head">
        <span className="popover-title">Notificações</span>
        <a className="link">Marcar todas como lidas</a>
      </div>
      <div className="popover-body">
        {NOTIFS.map(n => (
          <div key={n.id} className={`notif ${n.unread ? 'notif-unread' : ''}`} style={{position:'relative'}}>
            <div className={`notif-icon ${n.type}`}>{n.icon}</div>
            <div>
              <div className="notif-text">{n.text}</div>
              <div className="notif-time">{n.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   KPIs
   ────────────────────────────────────────────────────────── */
function Sparkline({ points, color }) {
  // points: array of numbers 0..1 (height ratio)
  const W = 90, H = 38;
  const n = points.length;
  const step = W / (n - 1);
  const path = points.map((p, i) => `${i ? 'L' : 'M'} ${i * step} ${H - p * (H - 6) - 3}`).join(' ');
  const area = `${path} L ${W} ${H} L 0 ${H} Z`;
  return (
    <svg className="spark" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`g-${color.replace('#','')}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".24"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#g-${color.replace('#','')})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function KPI({ label, value, delta, deltaDir, meta, icon, sparkPoints, sparkColor }) {
  return (
    <div className="kpi">
      <div className="kpi-head">
        <span className="kpi-label">{label}</span>
        <div className="kpi-icon">{icon}</div>
      </div>
      <div className="kpi-value">{value}</div>
      <div className="kpi-meta">
        {delta != null && (
          <span className={`delta ${deltaDir}`}>
            {deltaDir === 'up' && I.arrowUp}
            {deltaDir === 'down' && I.arrowDn}
            {delta}
          </span>
        )}
        <span>{meta}</span>
      </div>
      {sparkPoints && <Sparkline points={sparkPoints} color={sparkColor || 'var(--primary)'} />}
    </div>
  );
}

function KPIHero({ label, value, sub, variant, icon, onClick }) {
  return (
    <div className={`kpi-hero is-${variant}`} onClick={onClick}>
      <div className="lbl">
        {variant === 'dark' && <span className="pulse-dot" />}
        {icon}
        <span>{label}</span>
      </div>
      <div>
        <div className="v">{value}</div>
        <div className="sub">{sub}</div>
      </div>
    </div>
  );
}

function KPIs() {
  return (
    <div className="grid grid-kpis">
      <KPIHero
        variant="dark"
        label="MRR Mensal"
        value="R$ 4.400"
        sub="Receita recorrente · +11.4% mês"
      />
      <KPIHero
        variant="violet"
        label="Clientes Ativos"
        value="18"
        sub="Na base da agência · +2 mês"
        icon={I.users}
      />
      <KPI
        label="Leads do mês"
        value="247"
        delta="+18%"
        deltaDir="up"
        meta="Meta 220 · Tráfego"
        icon={I.trending}
        sparkPoints={[.3, .35, .42, .38, .48, .52, .55, .6, .58, .65, .7, .75]}
        sparkColor="#16A34A"
      />
      <KPI
        label="Tarefas abertas"
        value="34"
        delta="9 hoje"
        deltaDir="flat"
        meta="3 vencendo"
        icon={I.zap}
        sparkPoints={[.5, .55, .48, .52, .5, .58, .6, .55, .58, .6, .55, .5]}
        sparkColor="#B45309"
      />
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   AGENDA — Today's timeline
   ────────────────────────────────────────────────────────── */
const AGENDA = [
  { id:1, time:'08:30', status:'done',     title:'Daily da equipe',                    type:'internal', tag:'Interna',  icon:I.users,    people:['BM','CL','MR'], meta:'15 min · Meet' },
  { id:2, time:'10:00', status:'done',     title:'Aprovação de criativos · MP Seminovos', type:'review',   tag:'Aprovação',icon:I.check,    people:['BM'],             meta:'Vídeo + 6 artes' },
  { id:3, time:'11:30', status:'now',      title:'Briefing — Dia dos Namorados · Joalheria Aura', type:'meeting', tag:'Reunião', icon:I.videoCam, people:['BM','MR'],     meta:'45 min · Cliente novo' },
  { id:4, time:'14:00', status:'upcoming', title:'Revisão de tráfego · Estúdio Norte', type:'review',   tag:'Tráfego',  icon:I.trending, people:['CL'],             meta:'Mensal · ROAS 3.2x' },
  { id:5, time:'16:00', status:'upcoming', title:'Entrega: roteiros maio · Padaria do Vale', type:'delivery', tag:'Entrega', icon:I.folder, people:['MR','BM'],     meta:'4 roteiros · 16 artes' },
  { id:6, time:'17:30', status:'upcoming', title:'Call de fechamento — Lead Premium',  type:'call',     tag:'Comercial',icon:I.message,  people:['BM'],             meta:'Proposta R$ 4.800/mês' },
];

const avPalette = {
  'BM': 'linear-gradient(135deg,#FCA5A5,#E11D48)',
  'CL': 'linear-gradient(135deg,#A78BFA,#6D28D9)',
  'MR': 'linear-gradient(135deg,#5EEAD4,#0F766E)',
};

function AgendaToday() {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title-group">
          <div className="card-title">
            Hoje
            <span style={{fontSize:12,color:'var(--text-muted)',fontWeight:500}}>· Quinta · 21 mai</span>
          </div>
          <div className="card-sub">6 compromissos · 2 concluídos · 1 em andamento</div>
        </div>
        <div className="card-actions">
          <a className="link">Ver semana {I.arrowRt}</a>
        </div>
      </div>
      <div className="card-body" style={{padding:'8px 18px 14px',gap:0,position:'relative'}}>
        <div className="timeline">
          {AGENDA.map((a, i) => (
            <div key={a.id} className={`tl-row ${a.status === 'done' ? 'is-done' : ''}`}>
              <div className="tl-time">
                {a.status === 'now' ? <strong>{a.time}</strong> : a.time}
              </div>
              <div className={`tl-dot ${a.status === 'now' ? 'is-now' : a.status === 'done' ? 'is-done' : ''}`} />
              <div className="tl-body">
                <div className="tl-title">
                  {a.title}
                  {a.status === 'now' && (
                    <span className="tag tag-call" style={{padding:'1px 6px',fontSize:10}}>AGORA</span>
                  )}
                </div>
                <div className="tl-meta">
                  <span className={`tag tag-${a.type}`}>{a.tag}</span>
                  <span>{a.meta}</span>
                </div>
              </div>
              <div className="tl-avatars">
                {a.people.map(p => (
                  <span key={p} className="av" style={{background: avPalette[p] || 'linear-gradient(135deg,#D6D3D1,#78716C)'}}>{p}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="card-foot">
        <span className="muted" style={{fontSize:12}}>Próximo: <strong style={{color:'var(--text)'}}>Briefing Joalheria Aura</strong> em 18 min</span>
        <button className="btn btn-secondary btn-sm">{I.plus} Agendar</button>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   UPCOMING — Calendário comercial
   ────────────────────────────────────────────────────────── */
const UPCOMING = [
  { id:1, m:'mai', d:'24', title:'Dia das Mães — pós-data',         meta:'Carrossel de agradecimento · 3 clientes', leadTime: 3,  leadClass:'is-urgent', kind:'sazonal' },
  { id:2, m:'jun', d:'12', title:'Dia dos Namorados',                 meta:'Tráfego pago · 4 clientes engajados',     leadTime: 22, leadClass:'',          kind:'sazonal' },
  { id:3, m:'jun', d:'15', title:'Reunião mensal — Joalheria Aura',   meta:'Revisão de performance · presencial',     leadTime: 25, leadClass:'',          kind:'cliente' },
  { id:4, m:'jul', d:'07', title:'Festas Juninas',                    meta:'Pack de artes · oportunidade alta',       leadTime: 47, leadClass:'is-safe',   kind:'sazonal' },
  { id:5, m:'ago', d:'11', title:'Dia dos Pais',                      meta:'Lead time 60d · planejar até 12/jun',     leadTime: 82, leadClass:'is-safe',   kind:'sazonal' },
];

function Upcoming() {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title-group">
          <div className="card-title">Calendário comercial</div>
          <div className="card-sub">Próximas datas e oportunidades</div>
        </div>
        <div className="card-actions">
          <a className="link">Ver tudo {I.arrowRt}</a>
        </div>
      </div>
      <div className="card-body" style={{paddingTop:6}}>
        <div className="upcoming">
          {UPCOMING.map(u => (
            <div key={u.id} className="upc">
              <div className="upc-date">
                <div className="m">{u.m}</div>
                <div className="d">{u.d}</div>
              </div>
              <div className="upc-body">
                <div className="upc-title">{u.title}</div>
                <div className="upc-meta">
                  <span className={`lead-time ${u.leadClass}`}>
                    {I.clock} em {u.leadTime}d
                  </span>
                  <span className="dot-sep" />
                  <span>{u.meta}</span>
                </div>
              </div>
              <span className="upc-cta">Contatar {I.chevRt}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   ALERTS — Campanhas em risco
   ────────────────────────────────────────────────────────── */
const ALERTS = [
  { id:1, level:'critical', icon:I.alert, title:'ROAS abaixo do alvo — Joalheria Aura', meta:'Tráfego pago · 2.1x (alvo 3.5x)', counter:'48h sem ajuste' },
  { id:2, level:'warning',  icon:I.clock, title:'Aprovação pendente — Estúdio Norte', meta:'4 artes · cliente sem resposta',   counter:'há 3 dias' },
  { id:3, level:'warning',  icon:I.paperclip, title:'Briefing incompleto — Padaria do Vale', meta:'Faltando referências de marca',    counter:'2 itens' },
  { id:4, level:'info',     icon:I.info, title:'Oportunidade: aumentar verba — MP Seminovos', meta:'CPL 28% abaixo do alvo no mês',    counter:'sugestão' },
];

function Alerts() {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title-group">
          <div className="card-title">
            Alertas e oportunidades
            <span style={{
              fontSize:10,fontWeight:700,letterSpacing:'.06em',
              background:'var(--danger-bg)',color:'var(--danger)',
              padding:'2px 6px',borderRadius:'var(--radius-pill)'
            }}>4 ATIVOS</span>
          </div>
          <div className="card-sub">Itens que precisam de atenção da equipe</div>
        </div>
        <div className="card-actions">
          <a className="link">Histórico {I.arrowRt}</a>
        </div>
      </div>
      <div className="card-body" style={{paddingTop:6}}>
        <div className="alerts">
          {ALERTS.map(a => (
            <div key={a.id} className={`alert-row is-${a.level}`}>
              <div className="alert-icon">{a.icon}</div>
              <div className="alert-body">
                <div className="alert-title">{a.title}</div>
                <div className="alert-meta">{a.meta}</div>
              </div>
              <span className="alert-counter">{a.counter}</span>
              <span className="alert-arrow">{I.chevRt}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   TEAM — Equipe ativa
   ────────────────────────────────────────────────────────── */
const TEAM = [
  { name:'Bruno Mendes',    role:'Sócio · Comercial',     status:'busy',   meta:'2 reuniões · 14 tasks', av:'BM', color:'linear-gradient(135deg,#FCA5A5,#E11D48)' },
  { name:'Carla Lopes',     role:'Gestora de Tráfego',    status:'online', meta:'em "Aura · perf."',     av:'CL', color:'linear-gradient(135deg,#A78BFA,#6D28D9)' },
  { name:'Marcos Reis',     role:'Estrategista',          status:'online', meta:'4 roteiros em revisão', av:'MR', color:'linear-gradient(135deg,#5EEAD4,#0F766E)' },
  { name:'Júlia Aoki',      role:'Designer',              status:'busy',   meta:'foco · até 16h',        av:'JA', color:'linear-gradient(135deg,#FCD34D,#B45309)' },
  { name:'Pedro Sant\'Anna', role:'Editor de Vídeo',       status:'away',   meta:'fora · volta 14h',      av:'PS', color:'linear-gradient(135deg,#93C5FD,#1D4ED8)' },
];

function Team() {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title-group">
          <div className="card-title">Equipe agora</div>
          <div className="card-sub">5 ativos · 1 fora · status em tempo real</div>
        </div>
        <a className="link">Gerenciar {I.arrowRt}</a>
      </div>
      <div className="card-body" style={{paddingTop:6}}>
        <div className="team">
          {TEAM.map(t => (
            <div key={t.av} className="team-row">
              <div className="team-av" style={{background:t.color}}>
                {t.av}
                <span className={`team-status ${t.status}`} />
              </div>
              <div>
                <div className="team-name">{t.name}</div>
                <div className="team-role">{t.role}</div>
              </div>
              <span className="team-meta">{t.meta}</span>
              <button className="icon-btn" style={{width:28,height:28}} title="Mensagem">{I.message}</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   QUICK ADD DRAWER
   ────────────────────────────────────────────────────────── */
function QuickAddDrawer({ open, onClose, onSubmit }) {
  const [kind, setKind] = useState('tarefa');
  const [title, setTitle] = useState('');
  const [client, setClient] = useState('MP Seminovos');
  return (
    <>
      <div className={`drawer-overlay ${open ? 'open' : ''}`} onClick={onClose} />
      <aside className={`drawer ${open ? 'open' : ''}`}>
        <div className="drawer-head">
          <h3 className="drawer-title">Novo item</h3>
          <button className="icon-btn" onClick={onClose} title="Fechar">{I.x}</button>
        </div>
        <div className="drawer-body">
          <div className="field">
            <label>Tipo</label>
            <div className="chip-row">
              {['tarefa','reuniao','entrega','call'].map(k => (
                <button key={k} className={`chip ${kind === k ? 'is-selected' : ''}`} onClick={() => setKind(k)}>
                  {{tarefa:'Tarefa', reuniao:'Reunião', entrega:'Entrega', call:'Call comercial'}[k]}
                </button>
              ))}
            </div>
          </div>
          <div className="field">
            <label>Título</label>
            <input
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Aprovar criativos do Dia dos Namorados"
            />
          </div>
          <div className="field-row">
            <div className="field">
              <label>Cliente</label>
              <select value={client} onChange={(e) => setClient(e.target.value)}>
                <option>MP Seminovos</option>
                <option>Joalheria Aura</option>
                <option>Estúdio Norte</option>
                <option>Padaria do Vale</option>
                <option>Sem cliente</option>
              </select>
            </div>
            <div className="field">
              <label>Responsável</label>
              <select>
                <option>Bruno Mendes</option>
                <option>Carla Lopes</option>
                <option>Marcos Reis</option>
                <option>Júlia Aoki</option>
              </select>
            </div>
          </div>
          <div className="field-row">
            <div className="field">
              <label>Data</label>
              <input type="date" defaultValue="2026-05-21" />
            </div>
            <div className="field">
              <label>Horário</label>
              <input type="time" defaultValue="14:30" />
            </div>
          </div>
          <div className="field">
            <label>Observações</label>
            <textarea placeholder="Detalhes, links, anexos…" />
          </div>
        </div>
        <div className="drawer-foot">
          <button className="btn btn-ghost" onClick={onClose}>Cancelar</button>
          <button
            className="btn btn-primary"
            onClick={() => {
              onSubmit({ kind, title: title || 'Nova tarefa', client });
              setTitle('');
            }}
          >
            Criar {kind === 'tarefa' ? 'tarefa' : kind}
          </button>
        </div>
      </aside>
    </>
  );
}

/* ──────────────────────────────────────────────────────────
   COCKPIT PAGE
   ────────────────────────────────────────────────────────── */
function Cockpit({ onOpenDrawer }) {
  return (
    <div className="page-body">
      <PageHeader
        icon={I.home}
        eyebrow="Operação · Visão geral"
        title="Cockpit"
        subtitle="Quinta · 21 mai · 10:42 BRT · 4 compromissos restantes"
        actions={<>
          <button className="btn btn-secondary">{I.calendar} Agendar</button>
          <button className="btn btn-primary" onClick={onOpenDrawer}>{I.plus} Nova tarefa</button>
        </>}
      />

      <KPIs />

      <div className="grid grid-main">
        <AgendaToday />
        <Upcoming />
      </div>

      <div className="grid grid-secondary">
        <Alerts />
        <Team />
      </div>
    </div>
  );
}

Object.assign(window, { Cockpit, Sidebar, Topbar, QuickAddDrawer });
