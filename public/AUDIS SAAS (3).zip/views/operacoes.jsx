// operacoes.jsx — Vista de Operações (gravações, equipamentos, esteira)

const { useState: useOpState } = React;

const OP_ICONS = {
  camera: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>,
  mic:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>,
  film:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="7" y1="3" x2="7" y2="21"/><line x1="17" y1="3" x2="17" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/></svg>,
  pkg:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/></svg>,
  edit:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>,
  send:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
  plus:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  alert:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.3 3.86 1.82 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.86a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><circle cx="12" cy="17" r="1" fill="currentColor"/></svg>,
};

const PIPELINE = [
  {
    stage: 'Briefing',     count: 4, color: '#1D4ED8',
    items: [
      { client: 'Joalheria Aura', title: 'Roteiro · Dia dos Namorados',  due: 'em 2 dias',    owner: 'MR' },
      { client: 'MP Seminovos',   title: 'Roteiro · Junho',               due: 'em 4 dias',    owner: 'MR' },
      { client: 'Padaria do Vale',title: 'Briefing inicial',              due: 'amanhã',       owner: 'BM' },
      { client: 'Café Origem',    title: 'Brand refresh · roteiros',      due: 'em 5 dias',    owner: 'MR' },
    ],
  },
  {
    stage: 'Gravação',     count: 3, color: '#B45309',
    items: [
      { client: 'Joalheria Aura', title: '6 vídeos · Dia das Mães pós',   due: 'hoje 14h',     owner: 'JA' },
      { client: 'Estúdio Norte',  title: '4 reels · cobertura',           due: 'amanhã 10h',   owner: 'JA' },
      { client: 'MP Seminovos',   title: 'Catálogo · 12 itens',           due: 'sex 09h',      owner: 'PS' },
    ],
  },
  {
    stage: 'Edição',       count: 6, color: '#7C3AED',
    items: [
      { client: 'MP Seminovos',   title: 'Reels · Dia das Mães',          due: 'em 1 dia',     owner: 'PS' },
      { client: 'Joalheria Aura', title: '3 vídeos · institucional',      due: 'em 2 dias',    owner: 'PS' },
      { client: 'Café Origem',    title: 'Vídeo · Brand story',           due: 'em 3 dias',    owner: 'PS' },
      { client: 'Estúdio Norte',  title: '6 reels · Maio',                due: 'em 3 dias',    owner: 'PS' },
      { client: 'Padaria do Vale',title: '4 vídeos · Cardápio',           due: 'em 4 dias',    owner: 'PS' },
      { client: 'Studio Vert.',   title: 'Reel · convite evento',         due: 'em 5 dias',    owner: 'PS' },
    ],
  },
  {
    stage: 'Aprovação',    count: 4, color: '#B91C1C',
    items: [
      { client: 'MP Seminovos',   title: '6 reels finais',                due: 'cliente · 2d', owner: 'BM' },
      { client: 'Estúdio Norte',  title: '4 artes · institucional',       due: 'cliente · 1d', owner: 'BM' },
      { client: 'Joalheria Aura', title: 'Vídeo aniversário',             due: 'cliente · 3d', owner: 'BM' },
      { client: 'Café Origem',    title: 'Carrossel + reel',              due: 'cliente · 4d', owner: 'BM' },
    ],
  },
  {
    stage: 'Entregue',     count: 12, color: '#16A34A',
    items: [
      { client: 'MP Seminovos',   title: 'Pack Maio · 16 itens',          due: 'hoje',         owner: 'BM' },
      { client: 'Café Origem',    title: 'Brand video',                   due: 'ontem',        owner: 'BM' },
      { client: 'Joalheria Aura', title: 'Pack Mães · 9 vídeos',          due: '2 dias atrás', owner: 'BM' },
    ],
  },
];

const EQUIPAMENTOS = [
  { name: 'Sony A7 IV',         status: 'alocado',     to: 'Joalheria Aura · 21/05 14h' },
  { name: 'Sony A6700',         status: 'disponivel',  to: '—' },
  { name: 'DJI Ronin RS3',      status: 'alocado',     to: 'Estúdio Norte · 22/05 10h' },
  { name: 'Lapela Rode Wireless',status:'disponivel',  to: '—' },
  { name: 'Aputure 600d',       status: 'manutencao',  to: 'Em reparo · até 25/05' },
  { name: 'Tripé Manfrotto',    status: 'disponivel',  to: '—' },
  { name: 'Sony FX3',           status: 'alocado',     to: 'MP Seminovos · sex 09h' },
  { name: 'Kit lentes G-Master', status:'alocado',     to: 'Joalheria Aura · 21/05 14h' },
];

function Operacoes() {
  const [tab, setTab] = useOpState('esteira');

  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={OP_ICONS.film}
        eyebrow="Operação · Esteira de produção"
        title="Operações"
        subtitle="29 vídeos · 8 equipamentos · 4 entregas hoje"
        actions={<>
          <button className="btn btn-secondary">{OP_ICONS.pkg} Equipamentos</button>
          <button className="btn btn-primary">{OP_ICONS.plus} Nova gravação</button>
        </>}
      />

      <div className="page-tabs-row">
        <div className="tabs">
          <button className={`tab ${tab === 'esteira' ? 'is-active' : ''}`} onClick={() => setTab('esteira')}>Esteira</button>
          <button className={`tab ${tab === 'gravacoes' ? 'is-active' : ''}`} onClick={() => setTab('gravacoes')}>Gravações</button>
          <button className={`tab ${tab === 'equipamentos' ? 'is-active' : ''}`} onClick={() => setTab('equipamentos')}>Equipamentos</button>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l"><span style={{width:7,height:7,background:'#FCD34D',borderRadius:'50%'}}/>Em produção</div>
          <div className="v">29</div>
          <div className="meta">Distribuídos em 5 estágios</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">{OP_ICONS.film}Em edição</div>
          <div className="v">6</div>
          <div className="meta">Pedro Sant'Anna · 4 dias</div>
        </div>
        <div className="big-stat">
          <div className="l">{OP_ICONS.alert}Atrasados</div>
          <div className="v" style={{color:'var(--danger)'}}>2</div>
          <div className="meta">MP · Pack maio (1d) · Aura · institucional (2d)</div>
        </div>
        <div className="big-stat">
          <div className="l">{OP_ICONS.send}Entregas hoje</div>
          <div className="v" style={{color:'var(--success)'}}>4</div>
          <div className="meta">MP · Café Origem · Estúdio Norte · Aura</div>
        </div>
      </div>

      <div className="banner warning" style={{marginTop:'var(--gap-grid)'}}>
        {OP_ICONS.alert}
        <span className="grow"><b>2 entregas em atraso.</b> MP Seminovos (Pack maio · 1 dia) e Joalheria Aura (Institucional · 2 dias). Reorganizar prioridades?</span>
        <button className="banner-action">Ver atrasos</button>
      </div>

      {/* Pipeline Kanban */}
      <div className="kanban" style={{marginTop:'var(--gap-grid)'}}>
        {PIPELINE.map((col) => (
          <div key={col.stage} className="kanban-col">
            <div className="kanban-head" style={{borderTopColor: col.color}}>
              <div className="kanban-title">
                <span className="kanban-dot" style={{background: col.color}}/>
                <span>{col.stage}</span>
                <span className="kanban-count">{col.count}</span>
              </div>
              <button className="icon-btn" style={{width:24,height:24}}>{OP_ICONS.plus}</button>
            </div>
            <div className="kanban-list">
              {col.items.map((it, i) => (
                <div key={i} className="kanban-card">
                  <div className="kanban-client">{it.client}</div>
                  <div className="kanban-task">{it.title}</div>
                  <div className="kanban-meta">
                    <span>{it.due}</span>
                    <span className="kanban-owner" title={it.owner}>{it.owner}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Equipamentos */}
      <div className="card" style={{marginTop:'var(--gap-grid)'}}>
        <div className="card-head">
          <div className="card-title-group">
            <div className="card-title">{OP_ICONS.pkg} Equipamentos</div>
            <div className="card-sub">8 itens · 3 disponíveis · 1 em manutenção</div>
          </div>
          <button className="btn btn-secondary btn-sm">Gerenciar</button>
        </div>
        <div className="card-body" style={{padding:0}}>
          <table className="table">
            <thead>
              <tr>
                <th>Equipamento</th>
                <th>Status</th>
                <th>Alocado para</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {EQUIPAMENTOS.map((e, i) => (
                <tr key={i}>
                  <td><strong style={{fontWeight:700}}>{e.name}</strong></td>
                  <td>
                    {e.status === 'disponivel' && <span className="badge badge-success"><span className="dot"/>DISPONÍVEL</span>}
                    {e.status === 'alocado'    && <span className="badge badge-info"><span className="dot"/>ALOCADO</span>}
                    {e.status === 'manutencao' && <span className="badge badge-warning"><span className="dot"/>MANUTENÇÃO</span>}
                  </td>
                  <td className="muted" style={{fontSize:12}}>{e.to}</td>
                  <td className="right"><a className="link">Histórico →</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Operacoes });
