// agenda.jsx — Vista de Agenda mensal (calendário)

const { useState: useAgendaState, useMemo: useAgendaMemo } = React;

const AGENDA_ICONS = {
  chevL: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 6 9 12 15 18"/></svg>,
  chevR: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 6 15 12 9 18"/></svg>,
  plus:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  search:<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></svg>,
  filter:<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="3 4 21 4 14 13 14 20 10 22 10 13 3 4"/></svg>,
  cal:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
};

// Maio 2026: day 1 = Friday. (We're on May 21, 2026.)
// We construct a 6-week grid starting Sunday.
const MAY_2026_EVENTS = {
  1:  [{ type:'holiday',  label:'Dia do Trabalho' }],
  5:  [{ type:'meeting',  label:'Briefing Joalheria Aura' }, { type:'internal', label:'Daily ×3' }],
  6:  [{ type:'delivery', label:'Roteiros · Padaria' }],
  10: [{ type:'season',   label:'Dia das Mães' }, { type:'delivery', label:'Pack mães · 6 clientes' }],
  11: [{ type:'meeting',  label:'Revisão tráfego · 2' }],
  13: [{ type:'delivery', label:'Vídeos MP · maio' }],
  14: [{ type:'call',     label:'Lead premium · 17h' }],
  15: [{ type:'meeting',  label:'Mensal · 4 clientes' }, { type:'internal', label:'Revisão eq.' }],
  18: [{ type:'delivery', label:'Artes Estúdio Norte' }],
  19: [{ type:'meeting',  label:'Briefing · Joalheria' }],
  20: [{ type:'call',     label:'Fechamento · Aura' }, { type:'delivery', label:'Roteiros junho' }],
  21: [
    { type:'internal', label:'Daily ·08:30' },
    { type:'meeting',  label:'Briefing 11:30' },
    { type:'review',   label:'Tráfego 14:00' },
    { type:'delivery', label:'Entrega 16:00' },
  ],
  22: [{ type:'delivery', label:'Pack junho · 3 clientes' }],
  24: [{ type:'season',   label:'Pós Dia das Mães' }],
  26: [{ type:'meeting',  label:'Revisão semanal' }],
  28: [{ type:'delivery', label:'Roteiros · 12 itens' }],
  29: [{ type:'meeting',  label:'Aprovação Padaria' }],
};

const MAY_2026 = {
  monthName: 'Maio',
  year: 2026,
  daysInMonth: 31,
  startWeekday: 5,  // 0=Sun, May 1 = Fri (5)
  today: 21,
  prevMonthDays: 30, // April had 30 days
};

const FILTER_CHIPS = [
  { id: 'todos',      label: 'Todos',      count: 31 },
  { id: 'meeting',    label: 'Reuniões',   count: 8 },
  { id: 'delivery',   label: 'Entregas',   count: 9 },
  { id: 'call',       label: 'Calls',      count: 3 },
  { id: 'season',     label: 'Sazonal',    count: 3 },
  { id: 'internal',   label: 'Internas',   count: 8 },
];

function CalCell({ day, isOut, isToday, events }) {
  const visible = events ? events.slice(0, 3) : [];
  const overflow = events && events.length > 3 ? events.length - 3 : 0;
  return (
    <div className={`cal-cell ${isOut ? 'is-out' : ''} ${isToday ? 'is-today' : ''}`}>
      <div className="cal-day">{day}</div>
      {visible.map((ev, i) => (
        <div key={i} className={`cal-event ev-${ev.type === 'review' ? 'meeting' : ev.type}`}>
          <span className="dot" />
          <span style={{overflow:'hidden',textOverflow:'ellipsis'}}>{ev.label}</span>
        </div>
      ))}
      {overflow > 0 && <div className="cal-more">+ {overflow} mais</div>}
    </div>
  );
}

function buildCalendarCells() {
  const cells = [];
  const { daysInMonth, startWeekday, today, prevMonthDays } = MAY_2026;
  // Leading days from previous month
  for (let i = startWeekday - 1; i >= 0; i--) {
    cells.push({ day: prevMonthDays - i, isOut: true });
  }
  // Current month
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push({ day: d, isOut: false, isToday: d === today, events: MAY_2026_EVENTS[d] });
  }
  // Trailing to fill 42 cells (6 rows)
  let trail = 1;
  while (cells.length < 42) {
    cells.push({ day: trail++, isOut: true });
  }
  return cells;
}

function Agenda({ onOpenDrawer }) {
  const [filter, setFilter] = useAgendaState('todos');
  const [view, setView] = useAgendaState('month');
  const cells = useAgendaMemo(() => buildCalendarCells(), []);

  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={AGENDA_ICONS.cal}
        eyebrow="Operação · Calendário"
        title="Agenda"
        subtitle="Reuniões, entregas e datas sazonais · AUDIS OS"
        actions={<>
          <div className="tabs">
            <button className={`tab ${view === 'month' ? 'is-active' : ''}`} onClick={() => setView('month')}>Mês</button>
            <button className={`tab ${view === 'week' ? 'is-active' : ''}`} onClick={() => setView('week')}>Semana</button>
            <button className={`tab ${view === 'list' ? 'is-active' : ''}`} onClick={() => setView('list')}>Lista</button>
          </div>
          <button className="btn btn-secondary">{AGENDA_ICONS.filter} Filtros</button>
          <button className="btn btn-primary" onClick={onOpenDrawer}>{AGENDA_ICONS.plus} Novo</button>
        </>}
      />

      <div className="filter-bar">
        <div className="left">
          {FILTER_CHIPS.map(c => (
            <button
              key={c.id}
              className={`tab ${filter === c.id ? 'is-active' : ''}`}
              onClick={() => setFilter(c.id)}
              style={{height:30}}
            >
              <span>{c.label}</span>
              <span className="tab-count">{c.count}</span>
            </button>
          ))}
        </div>
        <div className="right">
          <div className="search" style={{height:34,minWidth:240}}>
            <span style={{display:'grid',placeItems:'center',width:14,height:14,color:'var(--text-muted)'}}>{AGENDA_ICONS.search}</span>
            <input placeholder="Buscar reunião…" />
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="cal-month">
            <span>{MAY_2026.monthName}</span>
            <span className="yr">{MAY_2026.year}</span>
          </div>
          <div className="cal-nav">
            <button className="btn btn-secondary btn-sm" style={{width:34,padding:0}}>{AGENDA_ICONS.chevL}</button>
            <button className="btn btn-secondary btn-sm">Hoje</button>
            <button className="btn btn-secondary btn-sm" style={{width:34,padding:0}}>{AGENDA_ICONS.chevR}</button>
          </div>
        </div>
        <div className="card-body" style={{paddingTop:0}}>
          <div className="cal-weekdays">
            {['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'].map(d => (
              <div key={d} className="cal-wd">{d}</div>
            ))}
          </div>
          <div className="cal-grid">
            {cells.map((c, i) => (
              <CalCell key={i} {...c} />
            ))}
          </div>

          <div className="legend" style={{marginTop:16}}>
            <span className="legend-item"><span className="legend-dot" style={{background:'#1D4ED8'}}/>Reunião</span>
            <span className="legend-item"><span className="legend-dot" style={{background:'var(--primary)'}}/>Entrega</span>
            <span className="legend-item"><span className="legend-dot" style={{background:'#16A34A'}}/>Call</span>
            <span className="legend-item"><span className="legend-dot" style={{background:'#B45309'}}/>Sazonal</span>
            <span className="legend-item"><span className="legend-dot" style={{background:'#B91C1C'}}/>Feriado</span>
            <span className="legend-item"><span className="legend-dot" style={{background:'#78716C'}}/>Interna</span>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Agenda });
