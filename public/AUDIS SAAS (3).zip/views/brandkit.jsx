// brandkit.jsx — Brand Kit (identidade visual do cliente)

const BK_ICONS = {
  drop:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2.5S5 10 5 14a7 7 0 0 0 14 0c0-4-7-11.5-7-11.5z"/></svg>,
  type:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>,
  image:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
  upload:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  file:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  copy:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>,
};

const BRAND_COLORS = [
  { role: 'Primária',   hex: '#6D28D9', name: 'Violeta AUDIS' },
  { role: 'Acento',     hex: '#A78BFA', name: 'Violeta claro' },
  { role: 'Texto',      hex: '#0C0A09', name: 'Carvão' },
  { role: 'Fundo',      hex: '#FAFAF9', name: 'Off-white' },
  { role: 'Sucesso',    hex: '#16A34A', name: 'Verde' },
  { role: 'Atenção',    hex: '#B45309', name: 'Âmbar' },
];

const BRAND_DOCS = [
  { name:'Guia de Marca · v3.pdf',     size:'2.4 MB', kind:'PDF',   date:'15 abr 2026' },
  { name:'Logo Pack (SVG + PNG).zip',  size:'8.1 MB', kind:'ZIP',   date:'15 abr 2026' },
  { name:'Mockups · Catálogo.fig',     size:'14 MB',  kind:'FIG',   date:'02 mai 2026' },
  { name:'Manual de Tom de Voz.docx',  size:'420 KB', kind:'DOC',   date:'09 mai 2026' },
];

function BrandKit() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={BK_ICONS.drop}
        eyebrow="Clientes · Identidade visual"
        title="Brand Kit"
        subtitle="Logos · paleta · tipografia · documentos"
        actions={<>
          <select className="select" defaultValue="MP Seminovos">
            <option>MP Seminovos</option>
            <option>Joalheria Aura</option>
            <option>Estúdio Norte</option>
            <option>Padaria do Vale</option>
          </select>
          <button className="btn btn-secondary">{BK_ICONS.copy} Duplicar</button>
          <button className="btn btn-primary">{BK_ICONS.upload} Atualizar</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'minmax(0, 1.2fr) minmax(0, 1fr)'}}>
        {/* Logo */}
        <div className="card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">{BK_ICONS.image} Logo principal</div>
              <div className="card-sub">PNG, SVG, formatos light + dark</div>
            </div>
            <div className="card-actions">
              <a className="link">Histórico →</a>
            </div>
          </div>
          <div className="card-body">
            <div style={{
              background: 'var(--surface-soft)',
              borderRadius: 'var(--radius)',
              padding: '32px',
              display:'grid',
              placeItems:'center',
              minHeight: 200,
              border:'1px solid var(--border)'
            }}>
              <div style={{
                width: 80, height: 80,
                background:'#10B981',
                borderRadius: 18,
                color:'white',
                display:'grid',
                placeItems:'center',
                fontFamily:'var(--font-display)',
                fontSize:32,
                fontWeight:800,
                letterSpacing:'-0.02em'
              }}>MP</div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4, 1fr)',gap:8,marginTop:12}}>
              {['SVG','PNG @1x','PNG @2x','PDF'].map(f => (
                <button key={f} className="btn btn-secondary btn-sm">{f}</button>
              ))}
            </div>
          </div>
        </div>

        {/* Tipografia */}
        <div className="card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">{BK_ICONS.type} Tipografia</div>
              <div className="card-sub">Família principal · 2 pesos</div>
            </div>
          </div>
          <div className="card-body">
            <div style={{
              padding: '20px',
              background:'var(--surface-soft)',
              borderRadius:'var(--radius)',
              border:'1px solid var(--border)'
            }}>
              <div style={{
                fontFamily:'var(--font-display)',
                fontSize:46,
                fontWeight:700,
                letterSpacing:'-0.022em',
                lineHeight:1.05,
                color:'var(--text)'
              }}>Mensagens que vendem.</div>
              <div style={{
                fontFamily:'var(--font-body)',
                fontSize:14,
                color:'var(--text-secondary)',
                marginTop:10,
                lineHeight:1.55
              }}>Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz 1234567890 — "olá!"</div>
              <div style={{display:'flex',gap:8,marginTop:14}}>
                <span className="badge badge-primary">Display · 700</span>
                <span className="badge badge-neutral">Body · 500</span>
                <span className="badge badge-neutral">Caption · 400</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cores */}
      <div className="card" style={{marginTop:'var(--gap-grid)'}}>
        <div className="card-head">
          <div className="card-title-group">
            <div className="card-title">{BK_ICONS.drop} Cores da marca</div>
            <div className="card-sub">Paleta principal · clique pra copiar</div>
          </div>
          <a className="link">Exportar paleta →</a>
        </div>
        <div className="card-body">
          <div className="swatch-grid">
            {BRAND_COLORS.map(c => (
              <div key={c.hex} className="swatch-card">
                <div className="swatch-color" style={{background:c.hex}}/>
                <div className="swatch-name">
                  <div className="role">{c.role}</div>
                  <h5>{c.name}</h5>
                  <div className="hex">{c.hex}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'minmax(0, 1fr) minmax(0, 1fr)', marginTop:'var(--gap-grid)'}}>
        {/* Documentos */}
        <div className="card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">Documentos & assets</div>
              <div className="card-sub">4 arquivos · 25 MB total</div>
            </div>
            <button className="btn btn-secondary btn-sm">{BK_ICONS.upload} Subir</button>
          </div>
          <div className="card-body" style={{padding:0}}>
            {BRAND_DOCS.map((doc, i) => (
              <div key={i} className="list-row" style={{gridTemplateColumns:'32px 1fr auto auto'}}>
                <div style={{
                  width:32,height:32,borderRadius:8,
                  background:'var(--primary-100)',
                  color:'var(--primary)',
                  display:'grid',placeItems:'center'
                }}>{BK_ICONS.file}</div>
                <div>
                  <div style={{fontSize:13.5,fontWeight:600,color:'var(--text)'}}>{doc.name}</div>
                  <div style={{fontSize:11.5,color:'var(--text-muted)'}}>{doc.kind} · {doc.size} · enviado {doc.date}</div>
                </div>
                <a className="link">Baixar</a>
                <a className="link">···</a>
              </div>
            ))}
          </div>
        </div>

        {/* Upload zone */}
        <div className="card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">Adicionar asset</div>
              <div className="card-sub">Imagens, fontes, mockups, vídeos</div>
            </div>
          </div>
          <div className="card-body">
            <div className="upload-zone">
              <div className="icon-bg">{BK_ICONS.upload}</div>
              <h4>Arraste arquivos aqui</h4>
              <p>Ou clique para selecionar · até 50 MB por arquivo<br/>SVG, PNG, JPG, PDF, FIG, MP4</p>
              <button className="btn btn-primary btn-sm" style={{marginTop:4}}>Selecionar do computador</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { BrandKit });
