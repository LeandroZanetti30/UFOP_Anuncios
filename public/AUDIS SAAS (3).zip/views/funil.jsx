// funil.jsx — Pipeline de Vendas (Lead → Fechado)

const { useState: useFunilState } = React;

const FN_ICONS = {
  funnel: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="3 4 21 4 14 13 14 20 10 22 10 13 3 4"/></svg>,
  plus:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  call:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>,
  mail:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16v16H4z"/><polyline points="22 6 12 13 2 6"/></svg>,
  filter: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="3 4 21 4 14 13 14 20 10 22 10 13 3 4"/></svg>,
};

const STAGES = [
  { id: 'lead',       label: 'Lead',         count: 12, color: '#A8A29E', value: 'R$ 14.4k' },
  { id: 'qualificado',label: 'Qualificado',  count: 7,  color: '#1D4ED8', value: 'R$ 18.9k' },
  { id: 'reuniao',    label: 'Reunião',      count: 5,  color: '#7C3AED', value: 'R$ 22.5k' },
  { id: 'proposta',   label: 'Proposta',     count: 3,  color: '#B45309', value: 'R$ 14.4k' },
  { id: 'fechado',    label: 'Fechado',      count: 2,  color: '#16A34A', value: 'R$  6.0k' },
];

const DEALS = {
  lead: [
    { name: 'Tropical Açaí',       contact: 'Lucas · Instagram', when: 'há 2h',  value: 'R$ 1.200' },
    { name: 'Pet Shop Modular',    contact: 'Indicação MP',      when: 'há 4h',  value: 'R$ 800'   },
    { name: 'Clínica Reset',       contact: 'Form site',         when: 'ontem',  value: 'R$ 1.500' },
    { name: 'Restaurante Tropos',  contact: 'Whatsapp',          when: 'ontem',  value: 'R$ 1.000' },
    { name: 'Tech AI Solutions',   contact: 'LinkedIn',          when: '2 dias', value: 'R$ 2.000' },
  ],
  qualificado: [
    { name: 'Studio Botânico',     contact: 'Reunião marcada',   when: 'em 1d',  value: 'R$ 2.400' },
    { name: 'Joalheria Lumière',   contact: 'Pediu portfólio',   when: 'em 2d',  value: 'R$ 3.500' },
    { name: 'Imobiliária Pôr-do-Sol',contact:'Hot lead · interessado',when:'em 2d', value:'R$ 4.800' },
    { name: 'Espaço Beleza Iva',   contact: 'Email enviado',     when: 'em 3d',  value: 'R$ 1.800' },
  ],
  reuniao: [
    { name: 'Joalheria Aura · Premium', contact: 'Upgrade plano', when: 'amanhã', value: 'R$ 4.800', hot: true },
    { name: 'Restaurante La Bohème',contact: 'Sexta · 14h',      when: 'em 2d',  value: 'R$ 3.200' },
    { name: 'Studio Pilates Flow', contact: 'Proposta nova',     when: 'em 4d',  value: 'R$ 2.400' },
  ],
  proposta: [
    { name: 'Clínica Eos · Dr Helena',contact:'R$ 4.800 enviada',when:'há 3d',   value: 'R$ 4.800', hot: true },
    { name: 'Studio Norte · ampliação',contact:'R$ 3.600 enviada',when:'há 5d',  value: 'R$ 3.600' },
    { name: 'Padaria Brioche',     contact: 'R$ 1.800 enviada',  when: 'há 1d',  value: 'R$ 1.800' },
  ],
  fechado: [
    { name: 'MP Seminovos',        contact: 'Contrato assinado · 21/05', when: 'hoje',  value: 'R$ 1.200' },
    { name: 'Café Origem',         contact: 'Contrato assinado · 18/05', when: '3d',    value: 'R$ 1.200' },
  ],
};

function Funil() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={FN_ICONS.funnel}
        eyebrow="Comercial · Pipeline"
        title="Funil"
        subtitle="29 deals · R$ 76.2k em aberto · 14% conversão"
        actions={<>
          <button className="btn btn-secondary">{FN_ICONS.filter} Filtros</button>
          <button className="btn btn-primary">{FN_ICONS.plus} Novo lead</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l">Pipeline total</div>
          <div className="v">R$ 76.2k</div>
          <div className="meta">29 deals · ticket médio R$ 2.6k</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">{FN_ICONS.funnel}Hot deals</div>
          <div className="v">2</div>
          <div className="meta">R$ 9.6k · alta probabilidade</div>
        </div>
        <div className="big-stat">
          <div className="l">Fechados · maio</div>
          <div className="v" style={{color:'var(--success)'}}>R$ 6.0k</div>
          <div className="meta">2 deals · meta R$ 8.0k (75%)</div>
        </div>
        <div className="big-stat">
          <div className="l">Taxa conversão</div>
          <div className="v">14%</div>
          <div className="meta">Lead → Fechado · últimos 90 dias</div>
        </div>
      </div>

      {/* Funnel bars visualization */}
      <div className="card" style={{marginTop:'var(--gap-grid)'}}>
        <div className="card-head">
          <div className="card-title-group">
            <div className="card-title">{FN_ICONS.funnel} Visão geral do funil</div>
            <div className="card-sub">Volume e valor por estágio</div>
          </div>
          <div className="card-actions">
            <a className="link">Período · Maio →</a>
          </div>
        </div>
        <div className="card-body">
          <div className="funnel-bars">
            {STAGES.map((s, i) => {
              const max = STAGES[0].count;
              const w = (s.count / max) * 100;
              return (
                <div key={s.id} className="funnel-row">
                  <div className="funnel-label">
                    <span className="funnel-dot" style={{background: s.color}} />
                    <span className="funnel-stage">{s.label}</span>
                    <span className="funnel-count">{s.count}</span>
                  </div>
                  <div className="funnel-bar-track">
                    <div className="funnel-bar-fill" style={{width: `${w}%`, background: s.color}}>
                      <span className="funnel-bar-value">{s.value}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Pipeline Kanban */}
      <div className="kanban" style={{marginTop:'var(--gap-grid)'}}>
        {STAGES.map((s) => (
          <div key={s.id} className="kanban-col">
            <div className="kanban-head" style={{borderTopColor: s.color}}>
              <div className="kanban-title">
                <span className="kanban-dot" style={{background: s.color}} />
                <span>{s.label}</span>
                <span className="kanban-count">{s.count}</span>
              </div>
              <span className="muted" style={{fontSize:10,fontWeight:700,letterSpacing:'.12em',textTransform:'uppercase'}}>{s.value}</span>
            </div>
            <div className="kanban-list">
              {(DEALS[s.id] || []).map((d, i) => (
                <div key={i} className={`kanban-card ${d.hot ? 'is-hot' : ''}`}>
                  {d.hot && <div className="kanban-hot-tag">🔥 HOT</div>}
                  <div className="kanban-client">{d.name}</div>
                  <div className="kanban-task" style={{color:'var(--text-muted)',fontSize:11.5,marginBottom:6}}>{d.contact}</div>
                  <div className="kanban-meta">
                    <span>{d.when}</span>
                    <span className="mono" style={{fontWeight:700,color:'var(--text)'}}>{d.value}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Funil });
