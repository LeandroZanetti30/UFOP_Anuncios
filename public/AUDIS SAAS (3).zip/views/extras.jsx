// solicitacoes-entregas.jsx — Solicitações, Entregas, Projetos, Conteúdo, Social, Aprendizado

const { useState: useSolState } = React;

const SE_ICONS = {
  msg:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-4-1L3 21l1.5-5.5A8.38 8.38 0 0 1 3 11.5a8.5 8.5 0 0 1 8.5-8.5 8.38 8.38 0 0 1 8.5 8.5z"/></svg>,
  folder:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>,
  film:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="7" y1="3" x2="7" y2="21"/><line x1="17" y1="3" x2="17" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/></svg>,
  zap:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 4 14 11 14 9 22 20 10 13 10 13 2"/></svg>,
  share:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></svg>,
  book:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>,
  plus:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  search:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></svg>,
  play:    <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20"/></svg>,
  image:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
  file:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  flag:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
};

/* ──────────────────────────────────────────────────────────
   SOLICITAÇÕES — caixa de entrada de pedidos dos clientes
   ────────────────────────────────────────────────────────── */
const SOLICITACOES = [
  { id: 1, client: 'MP Seminovos',    av: 'MP', cor: 'linear-gradient(135deg,#34D399,#10B981)', cat: 'social',    pri: 'alta',    status: 'aberta',     title: 'Reels novos · captação de leads',    desc: 'Precisamos de 3 reels novos com foco em conversão pra Junho', when: 'há 2h',  attach: 2 },
  { id: 2, client: 'Joalheria Aura',  av: 'JA', cor: 'linear-gradient(135deg,#FCD34D,#B45309)', cat: 'trafego',   pri: 'alta',    status: 'em_analise', title: 'Aumentar verba de tráfego em 30%',   desc: 'O ROAS tá voando, podemos investir mais. Pensei em R$ 1.500',   when: 'há 4h',  attach: 0 },
  { id: 3, client: 'Estúdio Norte',   av: 'EN', cor: 'linear-gradient(135deg,#93C5FD,#1D4ED8)', cat: 'audiovisual',pri:'normal',  status: 'em_producao',title: 'Vídeo institucional 2026 · roteiro',  desc: 'Roteiro pra vídeo institucional. Tom mais sério, foco em equipe', when: 'ontem', attach: 1 },
  { id: 4, client: 'Café Origem',     av: 'CO', cor: 'linear-gradient(135deg,#F472B6,#BE185D)', cat: 'design',    pri: 'baixa',   status: 'em_producao',title: 'Cardápio de inverno · novos pratos', desc: 'Vamos lançar 4 pratos novos. Precisamos das artes pra cardápio', when: 'ontem', attach: 5 },
  { id: 5, client: 'Padaria do Vale', av: 'PV', cor: 'linear-gradient(135deg,#FCA5A5,#E11D48)', cat: 'suporte',   pri: 'normal',  status: 'aberta',     title: 'Acesso ao app pra duas pessoas',     desc: 'Maria do financeiro e João do marketing precisam de login',     when: '2 dias', attach: 0 },
  { id: 6, client: 'Studio Vert.',    av: 'SV', cor: 'linear-gradient(135deg,#A78BFA,#7C3AED)', cat: 'social',    pri: 'normal',  status: 'concluida',  title: 'Stories da semana · 12 posts',       desc: 'Pacote de 12 stories já entregue e aprovado',                    when: '3 dias', attach: 0 },
];

const CAT_LABELS = {
  social: 'Social Media', trafego: 'Tráfego Pago', audiovisual: 'Audiovisual', design: 'Design', suporte: 'Suporte',
};

const STATUS_BADGE = {
  aberta:       { cls: 'badge-danger',  label: 'ABERTA · responder' },
  em_analise:   { cls: 'badge-warning', label: 'EM ANÁLISE' },
  em_producao:  { cls: 'badge-info',    label: 'EM PRODUÇÃO' },
  concluida:    { cls: 'badge-success', label: 'CONCLUÍDA' },
};

const PRI_BADGE = {
  alta:   { cls: 'badge-danger',  label: 'ALTA' },
  normal: { cls: 'badge-neutral', label: 'NORMAL' },
  baixa:  { cls: 'badge-neutral', label: 'BAIXA' },
};

function Solicitacoes() {
  const [filter, setFilter] = useSolState('todas');
  const filtered = filter === 'todas' ? SOLICITACOES : SOLICITACOES.filter(s => s.status === filter);

  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={SE_ICONS.msg}
        eyebrow="Clientes · Caixa de entrada"
        title="Solicitações"
        subtitle="6 solicitações · 2 abertas · responda em até 4h úteis"
        actions={<>
          <button className="btn btn-secondary">Exportar</button>
          <button className="btn btn-primary">{SE_ICONS.plus} Criar solicitação</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l">Abertas · responder</div>
          <div className="v" style={{color:'#FCA5A5'}}>2</div>
          <div className="meta">MP Seminovos · Padaria do Vale</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">Em produção</div>
          <div className="v">2</div>
          <div className="meta">Estúdio Norte · Café Origem</div>
        </div>
        <div className="big-stat">
          <div className="l">Tempo médio resposta</div>
          <div className="v">2h12</div>
          <div className="meta">Meta: 4h · Melhor que o esperado</div>
        </div>
        <div className="big-stat">
          <div className="l">Concluídas · maio</div>
          <div className="v" style={{color:'var(--success)'}}>18</div>
          <div className="meta">100% dentro do SLA</div>
        </div>
      </div>

      <div className="filter-bar" style={{marginTop:'var(--gap-grid)'}}>
        <div className="left">
          <div className="tabs">
            {[
              { id: 'todas',       label: 'Todas',        n: 6 },
              { id: 'aberta',      label: 'Abertas',      n: 2 },
              { id: 'em_analise',  label: 'Em análise',   n: 1 },
              { id: 'em_producao', label: 'Em produção',  n: 2 },
              { id: 'concluida',   label: 'Concluídas',   n: 1 },
            ].map(f => (
              <button key={f.id} className={`tab ${filter === f.id ? 'is-active' : ''}`} onClick={() => setFilter(f.id)}>
                {f.label} <span className="tab-count">{f.n}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="right">
          <div className="search" style={{height:34,minWidth:240}}>
            <span style={{display:'grid',placeItems:'center',width:14,height:14,color:'var(--text-muted)'}}>{SE_ICONS.search}</span>
            <input placeholder="Buscar solicitação…" />
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body" style={{padding:0}}>
          {filtered.map(s => {
            const stat = STATUS_BADGE[s.status];
            const pri = PRI_BADGE[s.pri];
            return (
              <div key={s.id} className="solicitacao-row">
                <div className="solicitacao-av" style={{background: s.cor}}>{s.av}</div>
                <div className="solicitacao-body">
                  <div className="solicitacao-head">
                    <strong className="solicitacao-title">{s.title}</strong>
                    <div className="solicitacao-badges">
                      <span className={`badge ${stat.cls}`}><span className="dot"/>{stat.label}</span>
                      <span className={`badge ${pri.cls}`}>{pri.label}</span>
                    </div>
                  </div>
                  <div className="solicitacao-meta">
                    <span><b>{s.client}</b></span>
                    <span className="dot-sep"/>
                    <span>{CAT_LABELS[s.cat]}</span>
                    <span className="dot-sep"/>
                    <span>{s.when}</span>
                    {s.attach > 0 && <><span className="dot-sep"/><span>📎 {s.attach} anexo{s.attach > 1 ? 's' : ''}</span></>}
                  </div>
                  <div className="solicitacao-desc">{s.desc}</div>
                </div>
                <div className="solicitacao-actions">
                  <button className="btn btn-ghost btn-sm">Ver →</button>
                  {s.status === 'aberta' && <button className="btn btn-primary btn-sm">Responder</button>}
                  {s.status !== 'aberta' && s.status !== 'concluida' && <button className="btn btn-secondary btn-sm">Atualizar</button>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   ENTREGAS — pasta de arquivos por cliente
   ────────────────────────────────────────────────────────── */
const ENTREGAS = [
  { id:1, client:'MP Seminovos',     av:'MP', cor:'linear-gradient(135deg,#34D399,#10B981)', kind:'video', title:'Pack Maio · 16 vídeos finais', when:'há 2h',     size:'320 MB', status:'aprovado',  count:16 },
  { id:2, client:'Joalheria Aura',   av:'JA', cor:'linear-gradient(135deg,#FCD34D,#B45309)', kind:'image', title:'Carrossel Dia das Mães · 12 frames', when:'há 4h', size:'48 MB',  status:'aprovado',  count:12 },
  { id:3, client:'Estúdio Norte',    av:'EN', cor:'linear-gradient(135deg,#93C5FD,#1D4ED8)', kind:'video', title:'Vídeo institucional · 1m20s', when:'ontem',     size:'180 MB', status:'em_revisao',count:1 },
  { id:4, client:'Café Origem',      av:'CO', cor:'linear-gradient(135deg,#F472B6,#BE185D)', kind:'image', title:'Cardápio inverno · 4 artes', when:'ontem',      size:'12 MB',  status:'aprovado',  count:4 },
  { id:5, client:'Padaria do Vale',  av:'PV', cor:'linear-gradient(135deg,#FCA5A5,#E11D48)', kind:'file',  title:'Manual de marca · v2.pdf', when:'2 dias',       size:'2.4 MB', status:'aprovado',  count:1 },
  { id:6, client:'Studio Vert.',     av:'SV', cor:'linear-gradient(135deg,#A78BFA,#7C3AED)', kind:'video', title:'Reel · convite evento', when:'3 dias',           size:'42 MB',  status:'aprovado',  count:1 },
];

function Entregas() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={SE_ICONS.folder}
        eyebrow="Clientes · Arquivos finais"
        title="Entregas"
        subtitle="35 entregas em maio · 320 GB · 100% dentro do prazo"
        actions={<>
          <button className="btn btn-secondary">Filtros</button>
          <button className="btn btn-primary">{SE_ICONS.plus} Nova entrega</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l">Entregas · maio</div>
          <div className="v">35</div>
          <div className="meta">+12 vs. abril (29)</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">Em revisão</div>
          <div className="v">3</div>
          <div className="meta">Estúdio Norte · 2 outros</div>
        </div>
        <div className="big-stat">
          <div className="l">Aprovadas</div>
          <div className="v" style={{color:'var(--success)'}}>32</div>
          <div className="meta">91% aprovação · 1ª revisão</div>
        </div>
        <div className="big-stat">
          <div className="l">Volume total</div>
          <div className="v">320 GB</div>
          <div className="meta">Storage · plano Pro 2 TB</div>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))', marginTop:'var(--gap-grid)'}}>
        {ENTREGAS.map(e => (
          <div key={e.id} className="entrega-card">
            <div className="entrega-cover">
              <div className="entrega-kind">
                {e.kind === 'video' && SE_ICONS.play}
                {e.kind === 'image' && SE_ICONS.image}
                {e.kind === 'file'  && SE_ICONS.file}
              </div>
              {e.count > 1 && <div className="entrega-count">×{e.count}</div>}
              {e.status === 'aprovado'   && <span className="entrega-tag" style={{background:'var(--success)'}}>APROVADO</span>}
              {e.status === 'em_revisao' && <span className="entrega-tag" style={{background:'var(--warning)'}}>REVISÃO</span>}
            </div>
            <div className="entrega-body">
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                <div className="solicitacao-av" style={{width:24,height:24,fontSize:10,background: e.cor}}>{e.av}</div>
                <span style={{fontSize:11,fontWeight:800,letterSpacing:'.06em',textTransform:'uppercase',color:'var(--text-muted)'}}>{e.client}</span>
              </div>
              <div style={{fontSize:13,fontWeight:700,lineHeight:1.3,marginBottom:6}}>{e.title}</div>
              <div style={{display:'flex',justifyContent:'space-between',fontSize:10.5,fontWeight:600,letterSpacing:'.08em',textTransform:'uppercase',color:'var(--text-muted)'}}>
                <span>{e.when}</span>
                <span>{e.size}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   PROJETOS — projetos especiais / campanhas
   ────────────────────────────────────────────────────────── */
const PROJETOS = [
  { id:1, name:'Lançamento Coleção Inverno · Joalheria Aura', client:'Joalheria Aura', av:'JA', cor:'linear-gradient(135deg,#FCD34D,#B45309)', start:'12 mai', end:'30 jun', progress:42, status:'em_andamento', team:['BM','MR','JA','PS'], milestones:6, completed:2 },
  { id:2, name:'Catálogo Maio Completo · MP Seminovos', client:'MP Seminovos', av:'MP', cor:'linear-gradient(135deg,#34D399,#10B981)', start:'01 mai', end:'31 mai', progress:78, status:'em_andamento', team:['BM','MR','PS'], milestones:5, completed:4 },
  { id:3, name:'Rebrand Visual · Estúdio Norte', client:'Estúdio Norte', av:'EN', cor:'linear-gradient(135deg,#93C5FD,#1D4ED8)', start:'15 abr', end:'15 jun', progress:65, status:'em_andamento', team:['BM','JA'], milestones:8, completed:5 },
  { id:4, name:'Campanha Dia dos Namorados · Multi-cliente', client:'4 clientes', av:'4C', cor:'linear-gradient(135deg,#F472B6,#BE185D)', start:'01 mai', end:'15 jun', progress:28, status:'planejamento', team:['BM','MR','PS','JA','CL'], milestones:12, completed:3 },
  { id:5, name:'Black November 2026 · Planejamento', client:'Multi-cliente', av:'BN', cor:'linear-gradient(135deg,#A78BFA,#7C3AED)', start:'15 ago', end:'30 nov', progress:5, status:'planejamento', team:['BM','MR'], milestones:14, completed:1 },
];

function Projetos() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={SE_ICONS.flag}
        eyebrow="Clientes · Campanhas grandes"
        title="Projetos"
        subtitle="5 projetos ativos · 15 milestones concluídos · 30 pendentes"
        actions={<>
          <button className="btn btn-secondary">Cronograma</button>
          <button className="btn btn-primary">{SE_ICONS.plus} Novo projeto</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l">Em andamento</div>
          <div className="v">3</div>
          <div className="meta">Joalheria Aura · MP · Estúdio Norte</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">Em planejamento</div>
          <div className="v">2</div>
          <div className="meta">Dia dos Namorados · Black November</div>
        </div>
        <div className="big-stat">
          <div className="l">Milestones</div>
          <div className="v">15/45</div>
          <div className="meta">33% concluídos · prazo apertado em Aura</div>
        </div>
        <div className="big-stat">
          <div className="l">Próxima entrega</div>
          <div className="v" style={{fontSize:18}}>30 mai</div>
          <div className="meta">Catálogo MP · em 9 dias</div>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1fr', marginTop:'var(--gap-grid)', gap:12}}>
        {PROJETOS.map(p => (
          <div key={p.id} className="card projeto-row">
            <div className="projeto-main">
              <div className="solicitacao-av" style={{width:42,height:42,fontSize:13,background:p.cor,flexShrink:0}}>{p.av}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
                  <strong style={{fontSize:14,fontWeight:800,letterSpacing:'-0.008em'}}>{p.name}</strong>
                  {p.status === 'em_andamento' && <span className="badge badge-info"><span className="dot"/>EM ANDAMENTO</span>}
                  {p.status === 'planejamento' && <span className="badge badge-warning"><span className="dot"/>PLANEJAMENTO</span>}
                </div>
                <div style={{fontSize:11.5,color:'var(--text-muted)',fontWeight:600,letterSpacing:'.04em',textTransform:'uppercase'}}>
                  {p.client} · {p.start} → {p.end} · {p.completed}/{p.milestones} milestones
                </div>
              </div>
              <div className="projeto-team">
                {p.team.slice(0,4).map((t, i) => (
                  <span key={t} className="team-tag" style={{zIndex: p.team.length - i}}>{t}</span>
                ))}
                {p.team.length > 4 && <span className="team-tag is-extra">+{p.team.length - 4}</span>}
              </div>
            </div>
            <div className="projeto-progress">
              <div className="projeto-progress-track">
                <div className="projeto-progress-fill" style={{width: `${p.progress}%`}}>
                  <span>{p.progress}%</span>
                </div>
              </div>
              <button className="btn btn-secondary btn-sm">Abrir →</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   CONTEÚDO — calendário editorial
   ────────────────────────────────────────────────────────── */
const CONTEUDO_KANBAN = [
  { stage: 'Ideação',     color: '#A8A29E',
    items: [
      { client:'Joalheria Aura', title:'Série: "Pedras que contam histórias"', kind:'reels',     when:'Junho' },
      { client:'MP Seminovos',   title:'Tutorial: como avaliar seu carro',     kind:'youtube',   when:'Junho' },
      { client:'Café Origem',    title:'POV: dia no café',                     kind:'tiktok',    when:'Junho' },
    ]},
  { stage: 'Roteiro',     color: '#1D4ED8',
    items: [
      { client:'Joalheria Aura', title:'Dia dos Namorados · Ana & Pedro',      kind:'reels',     when:'em 2d', author:'MR' },
      { client:'Estúdio Norte',  title:'Bastidores · ensaio fotográfico',      kind:'reels',     when:'em 3d', author:'MR' },
      { client:'Padaria do Vale',title:'Receita semanal · 5 vídeos',            kind:'reels',     when:'em 4d', author:'MR' },
    ]},
  { stage: 'Aprovação',   color: '#B45309',
    items: [
      { client:'MP Seminovos',   title:'Carrossel · top 5 carros do mês',      kind:'carrossel', when:'cliente · 1d' },
      { client:'Café Origem',    title:'Carrossel · cardápio inverno',         kind:'carrossel', when:'cliente · 2d' },
    ]},
  { stage: 'Programado',  color: '#7C3AED',
    items: [
      { client:'MP Seminovos',   title:'Reels Dia dos Namorados',              kind:'reels',     when:'12/jun 09h' },
      { client:'Joalheria Aura', title:'Story série · 7 itens',                 kind:'stories',   when:'24/mai 18h' },
      { client:'Estúdio Norte',  title:'Post institucional',                    kind:'post',      when:'25/mai 12h' },
      { client:'Café Origem',    title:'Carrossel cardápio',                    kind:'carrossel', when:'27/mai 09h' },
    ]},
  { stage: 'Publicado',   color: '#16A34A',
    items: [
      { client:'MP Seminovos',   title:'Reel · novidade do dia',                kind:'reels',     when:'hoje 14h · 4.2k views' },
      { client:'Joalheria Aura', title:'Stories pack',                          kind:'stories',   when:'hoje 11h · 1.8k views' },
    ]},
];

function Conteudo() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={SE_ICONS.zap}
        eyebrow="Marketing · Calendário editorial"
        title="Conteúdo"
        subtitle="22 itens no pipeline · 4 publicados hoje · 12 programados"
        actions={<>
          <button className="btn btn-secondary">Calendário</button>
          <button className="btn btn-primary">{SE_ICONS.plus} Nova ideia</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l">Pipeline</div>
          <div className="v">22</div>
          <div className="meta">Distribuídos em 5 estágios</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">Programados</div>
          <div className="v">12</div>
          <div className="meta">Próximos 7 dias</div>
        </div>
        <div className="big-stat">
          <div className="l">Publicados · maio</div>
          <div className="v" style={{color:'var(--success)'}}>38</div>
          <div className="meta">Meta: 40 · 95% do alvo</div>
        </div>
        <div className="big-stat">
          <div className="l">Engajamento médio</div>
          <div className="v">8.4%</div>
          <div className="meta">+2.1pp vs. abril</div>
        </div>
      </div>

      <div className="kanban" style={{marginTop:'var(--gap-grid)'}}>
        {CONTEUDO_KANBAN.map((col) => (
          <div key={col.stage} className="kanban-col">
            <div className="kanban-head" style={{borderTopColor: col.color}}>
              <div className="kanban-title">
                <span className="kanban-dot" style={{background: col.color}} />
                <span>{col.stage}</span>
                <span className="kanban-count">{col.items.length}</span>
              </div>
            </div>
            <div className="kanban-list">
              {col.items.map((it, i) => (
                <div key={i} className="kanban-card">
                  <div style={{display:'flex',gap:6,marginBottom:6}}>
                    <span className="badge badge-primary" style={{fontSize:9}}>{it.kind.toUpperCase()}</span>
                  </div>
                  <div className="kanban-client">{it.client}</div>
                  <div className="kanban-task">{it.title}</div>
                  <div className="kanban-meta">
                    <span>{it.when}</span>
                    {it.author && <span className="kanban-owner">{it.author}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   SOCIAL — performance por rede
   ────────────────────────────────────────────────────────── */
const REDES = [
  { name: 'Instagram', color: 'linear-gradient(135deg,#F472B6,#BE185D)', followers: '24.8k', delta:'+412', posts: 18, eng: '7.2%' },
  { name: 'TikTok',    color: 'linear-gradient(135deg,#1F2937,#000000)', followers: '8.4k',  delta:'+1.2k', posts: 9,  eng: '12.4%' },
  { name: 'YouTube',   color: 'linear-gradient(135deg,#EF4444,#B91C1C)', followers: '2.1k',  delta:'+86',   posts: 3,  eng: '4.8%' },
  { name: 'LinkedIn',  color: 'linear-gradient(135deg,#1E40AF,#0A2540)', followers: '892',   delta:'+28',   posts: 6,  eng: '3.2%' },
];

const SOCIAL_POSTS = [
  { client:'MP Seminovos', av:'MP', cor:'linear-gradient(135deg,#34D399,#10B981)', net:'Instagram', kind:'reels', title:'Top 5 carros do mês', views: '4.2k', likes: 312, when:'hoje 14h', performance:'+38%' },
  { client:'Joalheria Aura', av:'JA', cor:'linear-gradient(135deg,#FCD34D,#B45309)', net:'TikTok',    kind:'short', title:'Aliança ou solitário?',  views: '12.8k', likes: 1840, when:'hoje 09h', performance:'+62%' },
  { client:'Café Origem',  av:'CO', cor:'linear-gradient(135deg,#F472B6,#BE185D)', net:'Instagram', kind:'post',  title:'Cardápio inverno',       views: '1.4k', likes: 187,  when:'ontem 12h', performance:'+12%' },
  { client:'Estúdio Norte',av:'EN', cor:'linear-gradient(135deg,#93C5FD,#1D4ED8)', net:'Instagram', kind:'reels', title:'Bastidores · ensaio',    views: '2.8k', likes: 248,  when:'ontem 18h', performance:'+4%'  },
];

function Social() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={SE_ICONS.share}
        eyebrow="Marketing · Redes sociais"
        title="Social"
        subtitle="36.2k seguidores · 36 posts em maio · engajamento 6.8%"
        actions={<>
          <button className="btn btn-secondary">Calendário</button>
          <button className="btn btn-primary">{SE_ICONS.plus} Novo post</button>
        </>}
      />

      {/* Redes principais */}
      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        {REDES.map(r => (
          <div key={r.name} className="rede-card" style={{background: r.color}}>
            <div className="rede-name">{r.name}</div>
            <div className="rede-value">{r.followers}</div>
            <div className="rede-meta">
              <span className="rede-delta">{r.delta}</span>
              <span>{r.posts} posts · {r.eng}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="card" style={{marginTop:'var(--gap-grid)'}}>
        <div className="card-head">
          <div className="card-title-group">
            <div className="card-title">Posts recentes</div>
            <div className="card-sub">Performance dos últimos posts publicados</div>
          </div>
          <a className="link">Ver todos →</a>
        </div>
        <div className="card-body" style={{padding:0}}>
          <table className="table">
            <thead>
              <tr>
                <th>Cliente / Post</th>
                <th>Rede</th>
                <th className="right">Views</th>
                <th className="right">Likes</th>
                <th className="right">Performance</th>
                <th>Quando</th>
              </tr>
            </thead>
            <tbody>
              {SOCIAL_POSTS.map((p, i) => (
                <tr key={i}>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:10}}>
                      <div className="solicitacao-av" style={{width:30,height:30,fontSize:11,background:p.cor,flexShrink:0}}>{p.av}</div>
                      <div>
                        <div style={{fontWeight:700,fontSize:13}}>{p.title}</div>
                        <div className="muted" style={{fontSize:11}}>{p.client} · {p.kind}</div>
                      </div>
                    </div>
                  </td>
                  <td><span className="badge badge-neutral">{p.net}</span></td>
                  <td className="right num">{p.views}</td>
                  <td className="right num">{p.likes}</td>
                  <td className="right"><span className="badge badge-success">{p.performance}</span></td>
                  <td className="muted">{p.when}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────
   APRENDIZADO — cursos / tutoriais / treinamento
   ────────────────────────────────────────────────────────── */
const CURSOS = [
  { id:1, title:'Onboarding AUDIS · primeiros passos', cat:'Boas-vindas', duration:'24 min', lessons:6, progress: 100, by:'Equipe AUDIS', new:false },
  { id:2, title:'Briefing perfeito · vídeos que convertem', cat:'Roteiro', duration:'1h 12min', lessons:8, progress: 65, by:'Marcos Reis', new:false },
  { id:3, title:'Tráfego pago · estrutura de campanha', cat:'Marketing', duration:'2h 45min', lessons:14, progress: 30, by:'Carla Lopes', new:true },
  { id:4, title:'Captação caseira · qualidade pro celular', cat:'Audiovisual', duration:'48 min', lessons:5, progress: 0, by:'Júlia Aoki', new:true },
  { id:5, title:'Aprovação rápida · framework AUDIS', cat:'Processos', duration:'32 min', lessons:4, progress: 0, by:'Bruno Mendes', new:false },
  { id:6, title:'Análise mensal · interpretando o relatório', cat:'Marketing', duration:'56 min', lessons:7, progress: 0, by:'Carla Lopes', new:true },
];

function Aprendizado() {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={SE_ICONS.book}
        eyebrow="Sistema · Universidade AUDIS"
        title="Aprendizado"
        subtitle="6 cursos · 2 concluídos · 3 novos esta semana"
        actions={<>
          <button className="btn btn-secondary">Trilhas</button>
          <button className="btn btn-primary">{SE_ICONS.plus} Novo curso</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l">Em andamento</div>
          <div className="v">2</div>
          <div className="meta">Briefing perfeito (65%) · Tráfego (30%)</div>
        </div>
        <div className="big-stat is-violet">
          <div className="l">Novos</div>
          <div className="v">3</div>
          <div className="meta">Captação caseira · Análise mensal · Tráfego</div>
        </div>
        <div className="big-stat">
          <div className="l">Concluídos</div>
          <div className="v" style={{color:'var(--success)'}}>1</div>
          <div className="meta">Onboarding · certificado emitido</div>
        </div>
        <div className="big-stat">
          <div className="l">Horas estudadas</div>
          <div className="v">8h 12m</div>
          <div className="meta">Maio · meta 12h (68%)</div>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'repeat(auto-fill, minmax(320px, 1fr))', marginTop:'var(--gap-grid)'}}>
        {CURSOS.map(c => (
          <div key={c.id} className="curso-card">
            <div className="curso-cover">
              <div className="curso-play">{SE_ICONS.play}</div>
              {c.new && <span className="curso-tag-new">NOVO</span>}
              {c.progress === 100 && <span className="curso-tag-done">CONCLUÍDO ✓</span>}
              <div className="curso-duration">{c.duration}</div>
            </div>
            <div className="curso-body">
              <div className="curso-cat">{c.cat}</div>
              <div className="curso-title">{c.title}</div>
              <div className="curso-meta">
                <span>{c.lessons} aulas</span>
                <span className="dot-sep"/>
                <span>{c.by}</span>
              </div>
              {c.progress > 0 && c.progress < 100 && (
                <div className="curso-progress">
                  <div className="curso-progress-track">
                    <div className="curso-progress-fill" style={{width: `${c.progress}%`}} />
                  </div>
                  <span>{c.progress}% concluído</span>
                </div>
              )}
              {c.progress === 0 && (
                <button className="btn btn-primary btn-sm" style={{width:'100%', marginTop:8}}>{SE_ICONS.play} Começar</button>
              )}
              {c.progress > 0 && c.progress < 100 && (
                <button className="btn btn-secondary btn-sm" style={{width:'100%', marginTop:8}}>Continuar →</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Solicitacoes, Entregas, Projetos, Conteudo, Social, Aprendizado });
