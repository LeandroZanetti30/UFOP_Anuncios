// financeiro.jsx — Vista Financeiro (fluxo de caixa)

const { useState: useFinState } = React;

const FIN_ICONS = {
  wallet:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h16v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7"/><circle cx="17" cy="13" r="1.4" fill="currentColor"/></svg>,
  alert:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.3 3.86 1.82 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.86a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><circle cx="12" cy="17" r="1" fill="currentColor"/></svg>,
  up:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 10 12 4 18 10"/><line x1="12" y1="4" x2="12" y2="19"/></svg>,
  down:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="18 14 12 20 6 14"/><line x1="12" y1="5" x2="12" y2="20"/></svg>,
  plus:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  card:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>,
  refresh: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.65 4.36A9 9 0 0 0 20.5 15"/></svg>,
  pct:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>,
};

const TX = [
  { d:'21/05', t:'Mensalidade · Joalheria Aura',     cat:'Receita · Cliente',    val:'+ R$ 1.200,00', kind:'in' },
  { d:'21/05', t:'Ferramenta · ContaAzul',            cat:'Despesa · SaaS',       val:'− R$    79,90', kind:'out' },
  { d:'20/05', t:'Mensalidade · MP Seminovos',        cat:'Receita · Cliente',    val:'+ R$    400,00', kind:'in' },
  { d:'20/05', t:'Anúncios · Meta Ads (repasse)',    cat:'Despesa · Mídia',      val:'− R$ 1.840,00', kind:'out' },
  { d:'19/05', t:'Pró-labore · Bruno Mendes',         cat:'Despesa · Sócio',      val:'− R$ 3.000,00', kind:'out' },
  { d:'18/05', t:'Mensalidade · Estúdio Norte',       cat:'Receita · Cliente',    val:'+ R$    800,00', kind:'in' },
  { d:'17/05', t:'Aluguel · escritório',              cat:'Despesa · Fixo',       val:'− R$ 1.800,00', kind:'out' },
];

const PARTNERS = [
  { nm:'Bruno Mendes',   pct:'55%', val:'R$ 8.420,00', av:'BM', color:'linear-gradient(135deg,#FCA5A5,#E11D48)' },
  { nm:'Marcos Reis',    pct:'30%', val:'R$ 4.593,00', av:'MR', color:'linear-gradient(135deg,#5EEAD4,#0F766E)' },
  { nm:'Reserva opera.', pct:'15%', val:'R$ 2.296,00', av:'OP', color:'linear-gradient(135deg,#A78BFA,#6D28D9)' },
];

function MonthBars() {
  const months = [
    { m:'Dez', rec: 0.62, des: 0.48 },
    { m:'Jan', rec: 0.68, des: 0.52 },
    { m:'Fev', rec: 0.70, des: 0.55 },
    { m:'Mar', rec: 0.75, des: 0.58 },
    { m:'Abr', rec: 0.82, des: 0.63 },
    { m:'Mai', rec: 0.92, des: 0.71, current: true },
  ];
  const W = 720, H = 240, pad = 32;
  const innerW = W - pad * 2;
  const innerH = H - pad * 1.5;
  const groupW = innerW / months.length;
  const barW = (groupW - 12) / 2;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      {/* Grid */}
      {[.25, .5, .75].map((p, i) => (
        <line key={i} x1={pad} x2={W - pad} y1={pad + (1 - p) * innerH} y2={pad + (1 - p) * innerH}
              stroke="var(--divider)" strokeDasharray="2 4"/>
      ))}
      <line x1={pad} x2={W - pad} y1={pad + innerH} y2={pad + innerH} stroke="var(--border)"/>
      {months.map((m, i) => {
        const x = pad + i * groupW;
        const hRec = m.rec * innerH;
        const hDes = m.des * innerH;
        return (
          <g key={i}>
            <rect x={x + groupW/2 - barW - 3} y={pad + (innerH - hRec)} width={barW} height={hRec}
                  rx="3" fill={m.current ? '#16A34A' : '#86EFAC'} />
            <rect x={x + groupW/2 + 3} y={pad + (innerH - hDes)} width={barW} height={hDes}
                  rx="3" fill={m.current ? '#B91C1C' : '#FCA5A5'} />
            <text x={x + groupW/2} y={H - 8} textAnchor="middle" fontSize="11"
                  fontFamily="var(--font-display)" fontWeight="600"
                  fill={m.current ? 'var(--text)' : 'var(--text-muted)'}>{m.m}{m.current ? ' ·' : ''}</text>
          </g>
        );
      })}
      {/* Y axis labels */}
      <text x={pad - 6} y={pad + 4} textAnchor="end" fontSize="10" fill="var(--text-muted)" fontFamily="var(--font-mono)">R$ 10k</text>
      <text x={pad - 6} y={pad + innerH * .5 + 4} textAnchor="end" fontSize="10" fill="var(--text-muted)" fontFamily="var(--font-mono)">R$ 5k</text>
      <text x={pad - 6} y={pad + innerH + 4} textAnchor="end" fontSize="10" fill="var(--text-muted)" fontFamily="var(--font-mono)">0</text>
    </svg>
  );
}

function Financeiro() {
  const [tab, setTab] = useFinState('cashflow');

  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={FIN_ICONS.wallet}
        eyebrow="Sistema · Financeiro"
        title="Financeiro"
        subtitle="Fluxo de caixa · sócios · precificação · AUDIS OS"
        actions={<>
          <button className="btn btn-secondary">{FIN_ICONS.refresh} Atualizar</button>
          <button className="btn btn-primary">{FIN_ICONS.plus} Lançamento</button>
        </>}
      />

      <div className="page-tabs-row">
        <div className="tabs">
          <button className={`tab ${tab === 'cashflow' ? 'is-active' : ''}`} onClick={() => setTab('cashflow')}>{FIN_ICONS.wallet} Fluxo de caixa</button>
          <button className={`tab ${tab === 'pagamentos' ? 'is-active' : ''}`} onClick={() => setTab('pagamentos')}>{FIN_ICONS.card} Pagamentos</button>
          <button className={`tab ${tab === 'assinaturas' ? 'is-active' : ''}`} onClick={() => setTab('assinaturas')}>{FIN_ICONS.refresh} Assinaturas</button>
          <button className={`tab ${tab === 'precificador' ? 'is-active' : ''}`} onClick={() => setTab('precificador')}>{FIN_ICONS.pct} Precificador</button>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat is-dark">
          <div className="l"><span className="dot" style={{width:7,height:7,background:'#10B981',borderRadius:'50%'}}/> Saldo total</div>
          <div className="v">R$ 15.309,40</div>
          <div className="meta">Acumulado histórico · 3 contas</div>
        </div>
        <div className="big-stat">
          <div className="l">Receitas <span style={{marginLeft:'auto',color:'var(--success)'}}>{FIN_ICONS.up}</span></div>
          <div className="v" style={{color:'var(--success)'}}>R$ 9.180,00</div>
          <div className="meta">Mai/2026 · 12 transações</div>
        </div>
        <div className="big-stat">
          <div className="l">Despesas <span style={{marginLeft:'auto',color:'var(--danger)'}}>{FIN_ICONS.down}</span></div>
          <div className="v" style={{color:'var(--danger)'}}>R$ 6.879,90</div>
          <div className="meta">Mai/2026 · 19 transações</div>
        </div>
        <div className="big-stat">
          <div className="l">Resultado <span style={{marginLeft:'auto',color:'var(--info)'}}>{FIN_ICONS.up}</span></div>
          <div className="v" style={{color:'var(--info)'}}>R$ 2.300,10</div>
          <div className="meta">Margem 25% · positivo</div>
        </div>
      </div>

      <div className="banner success" style={{marginTop:'var(--gap-grid)'}}>
        {FIN_ICONS.up}
        <span className="grow"><b>Saldo saudável.</b> Reserva de emergência cobre 2.2 meses de operação · meta é 3 meses</span>
        <button className="banner-action">Ajustar metas</button>
      </div>

      <div className="grid" style={{gridTemplateColumns:'minmax(0,2fr) minmax(0,1fr)', marginTop:'var(--gap-grid)'}}>
        <div className="card chart-card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">Receitas vs. Despesas</div>
              <div className="card-sub">Últimos 6 meses · valores brutos</div>
            </div>
            <div className="chart-toolbar">
              <button className="tab" style={{height:28,padding:'0 10px'}}>Mensal</button>
              <button className="tab is-active" style={{height:28,padding:'0 10px'}}>6m</button>
              <button className="tab" style={{height:28,padding:'0 10px'}}>1a</button>
            </div>
          </div>
          <div className="card-body">
            <div className="chart-wrap" style={{minHeight:260}}><MonthBars /></div>
            <div className="chart-legend">
              <span className="chart-legend-item"><span className="chart-legend-swatch" style={{background:'#16A34A'}}/>Receita · <b>R$ 9.180</b></span>
              <span className="chart-legend-item"><span className="chart-legend-swatch" style={{background:'#B91C1C'}}/>Despesa · <b>R$ 6.880</b></span>
              <span className="chart-legend-item">Variação · <b style={{color:'var(--success)'}}>+12.2%</b> mês</span>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">Sócios</div>
              <div className="card-sub">Distribuição do resultado</div>
            </div>
            <a className="link">Gerenciar →</a>
          </div>
          <div className="card-body">
            <div className="partner-stack">
              {PARTNERS.map(p => (
                <div key={p.av} className="partner-row">
                  <div className="av" style={{background:p.color}}>{p.av}</div>
                  <div>
                    <div className="nm">{p.nm}</div>
                    <div className="pct">{p.pct} · participação</div>
                  </div>
                  <div className="val">{p.val}</div>
                </div>
              ))}
            </div>
            <div style={{paddingTop:14, borderTop:'1px solid var(--divider)',display:'flex',justifyContent:'space-between',fontSize:12}}>
              <span className="muted">Total a distribuir (mês)</span>
              <span className="mono" style={{fontWeight:600}}>R$ 15.309,00</span>
            </div>
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:'var(--gap-grid)'}}>
        <div className="card-head">
          <div className="card-title-group">
            <div className="card-title">Movimentações recentes</div>
            <div className="card-sub">7 lançamentos · maio 2026</div>
          </div>
          <div className="card-actions">
            <a className="link">Ver tudo →</a>
          </div>
        </div>
        <div className="card-body" style={{padding:0}}>
          <table className="table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Descrição</th>
                <th>Categoria</th>
                <th className="right">Valor</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {TX.map((tx, i) => (
                <tr key={i}>
                  <td className="num" style={{color:'var(--text-muted)'}}>{tx.d}</td>
                  <td><strong style={{fontWeight:600}}>{tx.t}</strong></td>
                  <td><span className="badge badge-neutral">{tx.cat}</span></td>
                  <td className="right num" style={{
                    color: tx.kind === 'in' ? 'var(--success)' : 'var(--text)',
                    fontWeight: 600
                  }}>{tx.val}</td>
                  <td className="right"><a className="link">Editar →</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Financeiro });
