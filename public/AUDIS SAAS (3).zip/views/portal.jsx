// portal.jsx — Portal do Cliente (visualização "como cliente vê")
// Reaproveita o shell mas troca o conteúdo da sidebar via prop.

const { useState: usePortalState } = React;

const PT_ICONS = {
  home:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>,
  cal:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
  trend:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 17 9 11 13 15 21 7"/></svg>,
  msg:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-4-1L3 21l1.5-5.5A8.38 8.38 0 0 1 3 11.5a8.5 8.5 0 0 1 8.5-8.5 8.38 8.38 0 0 1 8.5 8.5z"/></svg>,
  drop:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2.5S5 10 5 14a7 7 0 0 0 14 0c0-4-7-11.5-7-11.5z"/></svg>,
  book:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>,
  pix:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2 22 12 12 22 2 12z"/><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></svg>,
  eye:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
  check:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="5 12 10 17 19 7"/></svg>,
  play:    <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20"/></svg>,
  lock:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0v4"/></svg>,
  arrowRt: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 6 15 12 9 18"/></svg>,
  back:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 6 9 12 15 18"/></svg>,
};

const CHECKLIST = [
  { done: true,  label:'Acesso ao portal ativado',          meta:'21 abr · 14:22' },
  { done: false, label:'Primeiro roteiro disponível',        meta:'em revisão' },
  { done: false, label:'Primeiro vídeo aprovado',            meta:'aguardando' },
  { done: false, label:'Primeiros posts publicados no mês',  meta:'2 de 8' },
];

const VIDEOS = [
  { t:'Catálogo Maio · Reels 01', s:'15s · vertical', tag:'Aprovado' },
  { t:'Lançamento · Stories',     s:'8 stories',     tag:'Em revisão' },
  { t:'Bastidores · Equipe',      s:'45s · 16:9',    tag:'Aprovado' },
];

const ARTES = [
  { t:'Banner Site · Maio',       s:'1920×600',     tag:'Publicado' },
  { t:'Carrossel Instagram',      s:'10 frames',    tag:'Aprovado' },
  { t:'Story · Promoção',         s:'1080×1920',    tag:'Em revisão' },
  { t:'Newsletter · cabeçalho',   s:'600×200',      tag:'Aprovado' },
];

// Portal sidebar (cliente-facing)
function PortalSidebar({ active, onNavigate, onExit }) {
  const items = [
    { id: 'inicio',       label: 'Início',        icon: PT_ICONS.home },
    { id: 'agenda',       label: 'Agenda',        icon: PT_ICONS.cal },
    { id: 'trafego',      label: 'Tráfego',       icon: PT_ICONS.trend },
    { id: 'solicitacoes', label: 'Solicitações',  icon: PT_ICONS.msg, badge: '2' },
    { id: 'brand',        label: 'Brand Kit',     icon: PT_ICONS.drop },
    { id: 'tutoriais',    label: 'Tutoriais',     icon: PT_ICONS.book },
  ];
  return (
    <aside className="sidebar">
      <div className="sidebar-head" style={{justifyContent:'space-between'}}>
        <img className="logo-mark" src="assets/audis-icon.png" alt="AUDIS" style={{width:28,height:28,borderRadius:7}}/>
        <img className="logo-wordmark" src="assets/audis-logo.png" alt="audis"
             style={{height:20, opacity:1, maxWidth:90, transform:'none'}}/>
      </div>
      <nav className="sidebar-nav">
        <div className="nav-group-label" style={{opacity:1}}>Menu</div>
        {items.map(item => (
          <div
            key={item.id}
            className={`nav-item ${active === item.id ? 'is-active' : ''}`}
            onClick={() => onNavigate(item.id)}
          >
            <span className="nav-icon">{item.icon}</span>
            <span className="nav-label" style={{opacity:1}}>{item.label}</span>
            {item.badge && <span className="nav-badge" style={{opacity:1}}>{item.badge}</span>}
          </div>
        ))}
      </nav>
      <div className="sidebar-foot">
        <button className="workspace-pill" onClick={onExit} title="Voltar para visão da agência">
          <div style={{
            width:28,height:28,borderRadius:'var(--radius-sm)',
            background:'var(--surface-soft)',
            border:'1px solid var(--border)',
            display:'grid',placeItems:'center',
            color:'var(--text-muted)'
          }}>{PT_ICONS.back}</div>
          <div className="workspace-meta" style={{opacity:1}}>
            <div className="workspace-name">Sair do modo cliente</div>
            <div className="workspace-plan">Voltar para agência</div>
          </div>
        </button>
      </div>
    </aside>
  );
}

function Portal({ onExit }) {
  const [tab, setTab] = usePortalState('inicio');
  return (
    <div className="app-shell is-expanded" style={{
      gridTemplateColumns:'232px 1fr',
      // Use a slightly different surface treatment to differentiate
      // background subtly so user knows they're viewing as client
    }}>
      <PortalSidebar active={tab} onNavigate={setTab} onExit={onExit} />

      <main className="main">
        <header className="topbar">
          <div className="crumb">
            <span className="badge badge-info" style={{fontSize:10.5,letterSpacing:'.04em',textTransform:'uppercase'}}>
              <span className="dot"/>Visualizando como cliente
            </span>
            <span className="crumb-current" style={{marginLeft:8}}>MP Seminovos</span>
          </div>
          <div style={{flex:1}}/>
          <button className="btn btn-secondary btn-sm">Sair do modo cliente</button>
          <button className="icon-btn" title="Notificações">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width:18,height:18}}><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
          </button>
          <div className="avatar" style={{background:'linear-gradient(135deg,#34D399,#10B981)'}}>MP</div>
        </header>

        <div className="page-body view-enter">
          {/* Banner */}
          <div className="portal-banner">
            <div className="client-mark">MP</div>
            <div>
              <div className="lbl">Bem-vindo ao app</div>
              <h2>MP Seminovos</h2>
            </div>
            <div className="actions">
              <button className="btn-pix">{PT_ICONS.pix} Pagar via PIX</button>
              <button className="icon-btn" style={{color:'rgba(255,255,255,.85)',background:'rgba(255,255,255,.08)',border:'1px solid rgba(255,255,255,.15)'}}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width:18,height:18}}><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
              </button>
            </div>
          </div>

          {/* Section nav */}
          <div className="page-tabs-row">
            <div className="tabs">
              <button className="tab is-active">Início</button>
              <button className="tab">Artes <span className="tab-count">14</span></button>
              <button className="tab">Roteiros <span className="tab-count">6</span></button>
              <button className="tab">Vídeos <span className="tab-count">3</span></button>
            </div>
          </div>

          {/* Status cards */}
          <div className="grid" style={{gridTemplateColumns:'repeat(3, 1fr)'}}>
            <div className="big-stat">
              <div className="l">Investimento mensal <span style={{marginLeft:'auto'}}>{PT_ICONS.eye}</span></div>
              <div className="v" style={{filter:'blur(8px)',userSelect:'none'}}>R$ 1.200,00</div>
              <div className="meta">Clique no olho pra revelar</div>
            </div>
            <div className="big-stat">
              <div className="l">Status financeiro <span style={{marginLeft:'auto',color:'var(--success)'}}>{PT_ICONS.check}</span></div>
              <div className="v" style={{color:'var(--success)'}}>Em dia</div>
              <div className="meta">Próximo vencimento · 21/jun</div>
            </div>
            <div className="big-stat">
              <div className="l">Acesso ao app <span style={{marginLeft:'auto',color:'var(--success)'}}>{PT_ICONS.lock}</span></div>
              <div className="v" style={{color:'var(--success)'}}>Ativo</div>
              <div className="meta">3 usuários cadastrados</div>
            </div>
          </div>

          {/* Configure workspace */}
          <div className="card" style={{marginTop:'var(--gap-grid)'}}>
            <div className="card-head">
              <div className="card-title-group">
                <div className="page-eyebrow"><span>Primeiros passos</span></div>
                <div className="card-title" style={{fontSize:16}}>
                  Configure seu workspace <span style={{color:'var(--primary)'}}>1 / 4</span>
                </div>
              </div>
              <button className="icon-btn" title="Dispensar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width:14,height:14}}><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg></button>
            </div>
            <div className="card-body">
              <div className="progress" style={{marginBottom:14}}>
                <div className="progress-fill" style={{width:'25%'}}/>
              </div>
              <div className="checklist">
                {CHECKLIST.map((c, i) => (
                  <div key={i} className={`check-item ${c.done ? 'is-done' : ''}`}>
                    <div className="check-mark">
                      {c.done ? PT_ICONS.check : <svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>}
                    </div>
                    <div className="check-label">{c.label}</div>
                    <div className="meta">{c.meta}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid" style={{gridTemplateColumns:'1fr 1fr', marginTop:'var(--gap-grid)'}}>
            <div className="card">
              <div className="card-head">
                <div className="card-title-group">
                  <div className="card-title">Vídeos prontos</div>
                  <div className="card-sub">Acesse e aprove suas entregas finais</div>
                </div>
                <a className="link">Ver todos →</a>
              </div>
              <div className="card-body" style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                {VIDEOS.map((v, i) => (
                  <div key={i} className="media-tile">
                    <div className="play">{PT_ICONS.play}</div>
                    <div className="meta">
                      <div className="t">{v.t}</div>
                      <div className="s">{v.s} · {v.tag}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="card-head">
                <div className="card-title-group">
                  <div className="card-title">Artes sociais</div>
                  <div className="card-sub">Acompanhe o cronograma de posts</div>
                </div>
                <a className="link">Calendário →</a>
              </div>
              <div className="card-body" style={{padding:0}}>
                {ARTES.map((a, i) => (
                  <div key={i} className="list-row" style={{gridTemplateColumns:'32px 1fr auto'}}>
                    <div style={{
                      width:32,height:32,borderRadius:8,
                      background:'var(--primary-100)',
                      color:'var(--primary)',
                      display:'grid',placeItems:'center'
                    }}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width:15,height:15}}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                    </div>
                    <div>
                      <div style={{fontSize:13.5,fontWeight:600,color:'var(--text)'}}>{a.t}</div>
                      <div style={{fontSize:11.5,color:'var(--text-muted)'}}>{a.s}</div>
                    </div>
                    <span className={`badge ${a.tag === 'Publicado' ? 'badge-success' : a.tag === 'Aprovado' ? 'badge-primary' : 'badge-warning'}`}>
                      {a.tag}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

Object.assign(window, { Portal });
