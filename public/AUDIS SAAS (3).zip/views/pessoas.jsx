// pessoas.jsx — Gestão de Pessoas (Clientes / Equipe / Usuários)

const { useState: usePessoasState } = React;

const PE_ICONS = {
  search:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></svg>,
  plus:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  grid:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
  list:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1.4" fill="currentColor"/><circle cx="4" cy="12" r="1.4" fill="currentColor"/><circle cx="4" cy="18" r="1.4" fill="currentColor"/></svg>,
  more:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>,
  edit:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>,
  mail:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16v16H4z"/><polyline points="22 6 12 13 2 6"/></svg>,
  bolt:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 4 14 11 14 9 22 20 10 13 10 13 2"/></svg>,
  lock:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0v4"/></svg>,
};

const CLIENTS = [
  { name:'MP Seminovos',         email:'contato@mpseminovos.com.br', mrr:'R$    400', status:'ativo',    pricing:'Fixo',    plan:'Visual QG',     stamp:'em dia',   gestor:'BM', av:'MP', color:'linear-gradient(135deg,#34D399,#10B981)' },
  { name:'Joalheria Aura',       email:'aline@joalheria-aura.com',   mrr:'R$ 1.200', status:'ativo',    pricing:'Performance', plan:'Visual QG · Tráfego', stamp:'em dia', gestor:'BM', av:'JA', color:'linear-gradient(135deg,#FCD34D,#B45309)' },
  { name:'Estúdio Norte',        email:'fabio@estudionorte.com.br',  mrr:'R$    800', status:'ativo',    pricing:'Fixo',    plan:'Visual QG',     stamp:'em dia',   gestor:'CL', av:'EN', color:'linear-gradient(135deg,#93C5FD,#1D4ED8)' },
  { name:'Padaria do Vale',      email:'pedido@padariadovale.com',    mrr:'R$    100', status:'ativo',    pricing:'Fixo',    plan:'Conteúdo',      stamp:'pendente', gestor:'MR', av:'PV', color:'linear-gradient(135deg,#FCA5A5,#E11D48)' },
  { name:'Studio Vert.',         email:'oi@vert.studio',              mrr:'R$    100', status:'ativo',    pricing:'Fixo',    plan:'Visual QG',     stamp:'em dia',   gestor:'CL', av:'SV', color:'linear-gradient(135deg,#A78BFA,#6D28D9)' },
  { name:'Café Origem',          email:'ola@cafeorigem.com.br',       mrr:'R$    100', status:'ativo',    pricing:'Fixo',    plan:'Conteúdo',      stamp:'em dia',   gestor:'MR', av:'CO', color:'linear-gradient(135deg,#F472B6,#BE185D)' },
  { name:'Tropical Açaí',        email:'tropical@acai.com',           mrr:'R$    100', status:'prospect', pricing:'—',       plan:'—',             stamp:'novo',     gestor:'—',  av:'TA', color:'linear-gradient(135deg,#86EFAC,#15803D)' },
  { name:'Atelier Norte',        email:'contato@ateliernorte.com',    mrr:'R$    100', status:'inativo',  pricing:'Fixo',    plan:'Visual QG',     stamp:'pausado',  gestor:'BM', av:'AN', color:'linear-gradient(135deg,#A8A29E,#57534E)' },
];

function Pessoas() {
  const [tab, setTab] = usePessoasState('clientes');
  const [filter, setFilter] = usePessoasState('todos');
  const [layout, setLayout] = usePessoasState('list');

  const filteredClients = CLIENTS.filter(c => filter === 'todos' || c.status === filter);

  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={PE_ICONS.user || <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>}
        eyebrow="Clientes · Base AUDIS OS"
        title="Pessoas"
        subtitle="Clientes, equipe interna e usuários do sistema"
        actions={<>
          <div className="tabs">
            <button className={`tab ${tab === 'clientes' ? 'is-active' : ''}`} onClick={() => setTab('clientes')}>
              Clientes <span className="tab-count">18</span>
            </button>
            <button className={`tab ${tab === 'equipe' ? 'is-active' : ''}`} onClick={() => setTab('equipe')}>
              Equipe <span className="tab-count">5</span>
            </button>
            <button className={`tab ${tab === 'usuarios' ? 'is-active' : ''}`} onClick={() => setTab('usuarios')}>
              Usuários <span className="tab-count">21</span>
            </button>
          </div>
          <button className="btn btn-primary">{PE_ICONS.plus} Novo cliente</button>
        </>}
      />

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <div className="big-stat">
          <div className="l">Total na base</div>
          <div className="v">18</div>
          <div className="meta">+2 novos em maio</div>
        </div>
        <div className="big-stat">
          <div className="l">Clientes ativos</div>
          <div className="v">18</div>
          <div className="meta"><span className="badge badge-success"><span className="dot"/>100%</span> retenção</div>
        </div>
        <div className="big-stat">
          <div className="l">Pendentes</div>
          <div className="v">1</div>
          <div className="meta">Padaria do Vale · aprovar onboarding</div>
        </div>
        <div className="big-stat is-emphasis">
          <div className="l" style={{color:'rgba(255,255,255,.75)'}}>MRR consolidado</div>
          <div className="v" style={{color:'white'}}>R$ 4.400,00</div>
          <div className="meta" style={{color:'rgba(255,255,255,.75)'}}>+R$ 200/mês vs. abril</div>
        </div>
      </div>

      <div className="filter-bar" style={{marginTop:'var(--gap-grid)'}}>
        <div className="left">
          <div className="tabs">
            <button className={`tab ${filter === 'todos' ? 'is-active' : ''}`} onClick={() => setFilter('todos')}>
              Todos <span className="tab-count">18</span>
            </button>
            <button className={`tab ${filter === 'prospect' ? 'is-active' : ''}`} onClick={() => setFilter('prospect')}>
              Prospect <span className="tab-count">1</span>
            </button>
            <button className={`tab ${filter === 'ativo' ? 'is-active' : ''}`} onClick={() => setFilter('ativo')}>
              Ativo <span className="tab-count">16</span>
            </button>
            <button className={`tab ${filter === 'inativo' ? 'is-active' : ''}`} onClick={() => setFilter('inativo')}>
              Inativo <span className="tab-count">1</span>
            </button>
          </div>
        </div>
        <div className="right">
          <div className="search" style={{height:34,minWidth:280}}>
            <span style={{display:'grid',placeItems:'center',width:14,height:14,color:'var(--text-muted)'}}>{PE_ICONS.search}</span>
            <input placeholder="Buscar cliente, e-mail, gestor…" />
          </div>
          <div className="tabs">
            <button className={`tab ${layout === 'list' ? 'is-active' : ''}`} onClick={() => setLayout('list')} title="Lista">{PE_ICONS.list}</button>
            <button className={`tab ${layout === 'grid' ? 'is-active' : ''}`} onClick={() => setLayout('grid')} title="Grid">{PE_ICONS.grid}</button>
          </div>
        </div>
      </div>

      {layout === 'list' ? (
        <div className="card">
          <div className="card-body" style={{padding:0}}>
            {filteredClients.map((c, i) => (
              <div key={i} className="list-row client-row">
                <div className="av" style={{background:c.color}}>{c.av}</div>
                <div>
                  <div className="name">
                    {c.name}
                    <span className="badge badge-success" style={{textTransform:'uppercase',fontSize:9.5,letterSpacing:'.05em'}}>
                      <span className="dot"/>{c.status}
                    </span>
                    <span className="badge badge-neutral" style={{textTransform:'uppercase',fontSize:9.5,letterSpacing:'.05em'}}>
                      {c.pricing}
                    </span>
                  </div>
                  <div className="meta">{c.email} · gestor {c.gestor === '—' ? <em style={{color:'var(--text-disabled)'}}>sem gestor</em> : c.gestor} · plano {c.plan}</div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div className="mono" style={{fontSize:13.5,fontWeight:600}}>{c.mrr}</div>
                  <div className="muted" style={{fontSize:11}}>
                    {c.stamp === 'em dia' && <span className="badge badge-success" style={{padding:'1px 6px',fontSize:10}}><span className="dot"/>em dia</span>}
                    {c.stamp === 'pendente' && <span className="badge badge-warning" style={{padding:'1px 6px',fontSize:10}}><span className="dot"/>pendente</span>}
                    {c.stamp === 'novo' && <span className="badge badge-info" style={{padding:'1px 6px',fontSize:10}}><span className="dot"/>novo lead</span>}
                    {c.stamp === 'pausado' && <span className="badge badge-neutral" style={{padding:'1px 6px',fontSize:10}}><span className="dot"/>pausado</span>}
                  </div>
                </div>
                <span className="badge badge-neutral" title="Plano">{c.plan}</span>
                <div className="actions">
                  <button className="btn btn-ghost btn-sm" title="IA assistente">{PE_ICONS.bolt} IA</button>
                  <button className="btn btn-secondary btn-sm">{PE_ICONS.lock} Liberar</button>
                  <button className="btn btn-ghost btn-sm" style={{padding:'0 8px'}} title="Editar">{PE_ICONS.edit}</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="grid" style={{gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))'}}>
          {filteredClients.map((c, i) => (
            <div key={i} className="card" style={{padding:'18px',gap:14}}>
              <div style={{display:'flex',alignItems:'center',gap:12}}>
                <div className="av client-row av" style={{
                  width:42,height:42,borderRadius:'50%',
                  background:c.color,
                  display:'grid',placeItems:'center',
                  color:'white',fontWeight:700,fontSize:14,letterSpacing:'-0.02em'
                }}>{c.av}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:14,fontWeight:600,color:'var(--text)'}}>{c.name}</div>
                  <div style={{fontSize:11.5,color:'var(--text-muted)',overflow:'hidden',textOverflow:'ellipsis'}}>{c.email}</div>
                </div>
                <button className="btn btn-ghost btn-sm" style={{padding:'0 6px'}}>{PE_ICONS.more}</button>
              </div>
              <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                <span className="badge badge-success" style={{textTransform:'uppercase',fontSize:9.5,letterSpacing:'.05em'}}>
                  <span className="dot"/>{c.status}
                </span>
                <span className="badge badge-neutral" style={{textTransform:'uppercase',fontSize:9.5,letterSpacing:'.05em'}}>
                  {c.pricing}
                </span>
                <span className="badge badge-primary" style={{fontSize:10,letterSpacing:'.02em'}}>{c.plan}</span>
              </div>
              <div style={{display:'flex',justifyContent:'space-between',paddingTop:10,borderTop:'1px solid var(--divider)'}}>
                <div>
                  <div style={{fontSize:10.5,fontWeight:600,letterSpacing:'.05em',textTransform:'uppercase',color:'var(--text-muted)'}}>MRR</div>
                  <div className="mono" style={{fontSize:15,fontWeight:600}}>{c.mrr}</div>
                </div>
                <button className="btn btn-secondary btn-sm">Abrir →</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Pessoas });
