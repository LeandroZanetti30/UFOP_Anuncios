// trafego.jsx — Vista de Tráfego (marketing metrics)

const { useState: useTrafegoState } = React;

const TR_ICONS = {
  dollar:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>,
  users:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>,
  target:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></svg>,
  eye:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
  click:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 4 14 11 14 9 22 20 10 13 10 13 2"/></svg>,
  trend:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 17 9 11 13 15 21 7"/><polyline points="14 7 21 7 21 14"/></svg>,
  upload:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  down:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="18 14 12 20 6 14"/><line x1="12" y1="5" x2="12" y2="20"/></svg>,
  up:      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 10 12 4 18 10"/><line x1="12" y1="4" x2="12" y2="19"/></svg>,
  link:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 1 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 1 0 7 7l1.7-1.7"/></svg>,
};

const CHANNELS = [
  { name: 'Meta Ads',     pct: 42, val: 'R$ 5.241', color: '#1877F2' },
  { name: 'Google Ads',   pct: 28, val: 'R$ 3.494', color: '#34A853' },
  { name: 'TikTok Ads',   pct: 18, val: 'R$ 2.246', color: '#0C0A09' },
  { name: 'LinkedIn',     pct: 8,  val: 'R$    998', color: '#0A66C2' },
  { name: 'Outros',       pct: 4,  val: 'R$    501', color: '#A8A29E' },
];

const CAMPAIGNS = [
  { name: 'Dia das Mães · Conversão',   ch: 'Meta Ads',   spend: 'R$ 1.840', leads: 84, cpl: 'R$ 21,90', roas: '3.8x', status: 'success' },
  { name: 'Catálogo Maio · Tráfego',    ch: 'Meta Ads',   spend: 'R$ 1.220', leads: 47, cpl: 'R$ 25,95', roas: '2.9x', status: 'success' },
  { name: 'Brand Awareness · YouTube',  ch: 'Google Ads', spend: 'R$    980', leads: 12, cpl: 'R$ 81,66', roas: '1.4x', status: 'warning' },
  { name: 'Lançamento Junho · Pre-roll', ch: 'TikTok Ads', spend: 'R$ 1.156', leads: 39, cpl: 'R$ 29,64', roas: '2.6x', status: 'success' },
  { name: 'Remarketing · Carrinho',     ch: 'Google Ads', spend: 'R$    480', leads: 24, cpl: 'R$ 20,00', roas: '4.2x', status: 'success' },
  { name: 'Captação B2B · Lookalike',   ch: 'LinkedIn',   spend: 'R$    320', leads:  3, cpl: 'R$106,66', roas: '0.8x', status: 'danger' },
];

function LineChart({ data, color, gradId }) {
  // data: array of {label, value}
  const W = 720, H = 220, pad = 30;
  const max = Math.max(...data.map(d => d.value)) * 1.15;
  const stepX = (W - pad * 2) / (data.length - 1);
  const yFor = (v) => H - pad - (v / max) * (H - pad * 2);
  const path = data.map((d, i) => `${i ? 'L' : 'M'} ${pad + i * stepX} ${yFor(d.value)}`).join(' ');
  const area = `${path} L ${pad + (data.length - 1) * stepX} ${H - pad} L ${pad} ${H - pad} Z`;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".22"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      {/* horizontal grid */}
      {[.25, .5, .75].map((p, i) => (
        <line key={i} x1={pad} x2={W - pad} y1={pad + p * (H - pad * 2)} y2={pad + p * (H - pad * 2)}
              stroke="var(--divider)" strokeDasharray="2 4" />
      ))}
      <path d={area} fill={`url(#${gradId})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      {data.map((d, i) => (
        <circle key={i} cx={pad + i * stepX} cy={yFor(d.value)} r="3" fill="white" stroke={color} strokeWidth="1.6"/>
      ))}
      {data.map((d, i) => (
        i % Math.ceil(data.length / 8) === 0 ? (
          <text key={i} x={pad + i * stepX} y={H - 8} textAnchor="middle" fontSize="10"
                fill="var(--text-muted)" fontFamily="var(--font-mono)">{d.label}</text>
        ) : null
      ))}
    </svg>
  );
}

function DonutChart({ data, total, label }) {
  const cx = 72, cy = 72, r = 56, sw = 18;
  const C = 2 * Math.PI * r;
  let offset = 0;
  return (
    <div className="donut">
      <svg viewBox="0 0 144 144">
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--surface-soft)" strokeWidth={sw} />
        {data.map((d, i) => {
          const len = (d.pct / 100) * C;
          const seg = (
            <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={d.color}
                    strokeWidth={sw}
                    strokeDasharray={`${len} ${C - len}`}
                    strokeDashoffset={-offset}
                    transform={`rotate(-90 ${cx} ${cy})`}
                    strokeLinecap="butt"
            />
          );
          offset += len;
          return seg;
        })}
      </svg>
      <div className="donut-center">
        <div className="v">{total}</div>
        <div className="l">{label}</div>
      </div>
    </div>
  );
}

function Trafego() {
  const [tab, setTab] = useTrafegoState('overview');
  const [client, setClient] = useTrafegoState('Joalheria Aura');

  const leadsData = [
    { label: '01', value: 4 }, { label: '03', value: 8 }, { label: '05', value: 12 }, { label: '07', value: 9 },
    { label: '09', value: 14 }, { label: '11', value: 18 }, { label: '13', value: 22 }, { label: '15', value: 28 },
    { label: '17', value: 24 }, { label: '19', value: 19 }, { label: '21', value: 26 }, { label: '23', value: 31 },
    { label: '25', value: 27 }, { label: '27', value: 24 }, { label: '29', value: 18 }, { label: '31', value: 15 },
  ];

  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={TR_ICONS.trend}
        eyebrow="Marketing · Tráfego pago"
        title="Tráfego"
        subtitle="Investimento, leads, CPL e ROAS · AUDIS OS"
        actions={<>
          <button className="btn btn-secondary">{TR_ICONS.link} Conectar fonte</button>
          <button className="btn btn-primary">{TR_ICONS.upload} Importar relatório</button>
        </>}
      />

      <div className="page-tabs-row">
        <div className="tabs">
          <button className={`tab ${tab === 'overview' ? 'is-active' : ''}`} onClick={() => setTab('overview')}>Visão geral</button>
          <button className={`tab ${tab === 'strategy' ? 'is-active' : ''}`} onClick={() => setTab('strategy')}>Estratégia</button>
          <button className={`tab ${tab === 'ops' ? 'is-active' : ''}`} onClick={() => setTab('ops')}>Operação</button>
          <button className={`tab ${tab === 'integration' ? 'is-active' : ''}`} onClick={() => setTab('integration')}>Integração</button>
        </div>
        <div style={{marginLeft:'auto',display:'flex',gap:8,flexWrap:'wrap'}}>
          <select className="select" value={client} onChange={(e) => setClient(e.target.value)}>
            <option>Joalheria Aura</option>
            <option>MP Seminovos</option>
            <option>Estúdio Norte</option>
            <option>Padaria do Vale</option>
            <option>Todos os clientes</option>
          </select>
          <select className="select" defaultValue="Maio">
            <option>Maio</option><option>Abril</option><option>Março</option>
          </select>
          <select className="select" defaultValue="2026">
            <option>2026</option><option>2025</option>
          </select>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'repeat(6, 1fr)'}}>
        <KPI4 label="Investimento" value="R$ 12.480" delta="+8.2%" dir="up" meta="vs. abril" icon={TR_ICONS.dollar} />
        <KPI4 label="Leads" value="247" delta="+18%" dir="up" meta="Meta 220" icon={TR_ICONS.users} />
        <KPI4 label="Custo / lead" value="R$ 50,52" delta="−12%" dir="up" meta="Alvo R$ 60" icon={TR_ICONS.target} />
        <KPI4 label="Alcance" value="184k" delta="+22%" dir="up" meta="Único" icon={TR_ICONS.eye} />
        <KPI4 label="Cliques" value="9.840" delta="+14%" dir="up" meta="CTR 5.3%" icon={TR_ICONS.click} />
        <KPI4 label="ROAS" value="3.2x" delta="−0.4x" dir="down" meta="Alvo 3.5x" icon={TR_ICONS.trend} emphasis />
      </div>

      <div className="grid" style={{gridTemplateColumns:'minmax(0,2fr) minmax(0,1fr)', marginTop:'var(--gap-grid)'}}>
        <div className="card chart-card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">Leads ao longo de maio</div>
              <div className="card-sub">{client} · Meta Ads + Google Ads + TikTok</div>
            </div>
            <div className="chart-toolbar">
              <button className="tab" style={{height:28,padding:'0 10px'}}>Leads</button>
              <button className="tab is-active" style={{height:28,padding:'0 10px'}}>Diário</button>
              <button className="tab" style={{height:28,padding:'0 10px'}}>Acumulado</button>
            </div>
          </div>
          <div className="card-body">
            <div className="chart-wrap"><LineChart data={leadsData} color="#6D28D9" gradId="g-leads" /></div>
            <div className="chart-legend">
              <span className="chart-legend-item"><span className="chart-legend-swatch" style={{background:'#6D28D9'}}/>Diário · <b>247</b></span>
              <span className="chart-legend-item">Mediana · <b>16/dia</b></span>
              <span className="chart-legend-item">Melhor dia · <b>23/05</b> (31)</span>
              <span className="chart-legend-item">Pior · <b>01/05</b> (4)</span>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title-group">
              <div className="card-title">Distribuição por canal</div>
              <div className="card-sub">Maio · investimento total</div>
            </div>
          </div>
          <div className="card-body">
            <div className="donut-row">
              <DonutChart data={CHANNELS} total="R$ 12.480" label="Investido" />
              <div className="donut-legend">
                {CHANNELS.map(c => (
                  <div key={c.name} className="donut-legend-row">
                    <span className="swatch" style={{background:c.color}}/>
                    <span className="name">{c.name}</span>
                    <span className="pct">{c.pct}%</span>
                    <span className="val">{c.val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:'var(--gap-grid)'}}>
        <div className="card-head">
          <div className="card-title-group">
            <div className="card-title">Campanhas ativas</div>
            <div className="card-sub">6 campanhas · ordenadas por investimento</div>
          </div>
          <div className="card-actions">
            <a className="link">Ver todas →</a>
          </div>
        </div>
        <div className="card-body" style={{padding:0}}>
          <table className="table">
            <thead>
              <tr>
                <th>Campanha</th>
                <th>Canal</th>
                <th className="right">Investido</th>
                <th className="right">Leads</th>
                <th className="right">CPL</th>
                <th className="right">ROAS</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {CAMPAIGNS.map((c, i) => (
                <tr key={i}>
                  <td><strong style={{fontWeight:600}}>{c.name}</strong></td>
                  <td><span className="badge badge-neutral">{c.ch}</span></td>
                  <td className="right num">{c.spend}</td>
                  <td className="right num">{c.leads}</td>
                  <td className="right num">{c.cpl}</td>
                  <td className="right">
                    <span className={`badge badge-${c.status}`}>
                      <span className="dot" />{c.roas}
                    </span>
                  </td>
                  <td className="right"><a className="link">Detalhes →</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function KPI4({ label, value, delta, dir, meta, icon, emphasis }) {
  return (
    <div className={`big-stat ${emphasis ? 'is-dark' : ''}`}>
      <div className="l">
        <span>{label}</span>
        <span style={{marginLeft:'auto', opacity:.6, width:14, height:14, display:'inline-flex'}}>{icon}</span>
      </div>
      <div className="v">{value}</div>
      <div className="meta">
        <span className={`delta ${dir}`} style={{padding:'1px 6px',borderRadius:5,fontSize:11}}>
          {dir === 'up' && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 10 12 4 18 10"/><line x1="12" y1="4" x2="12" y2="19"/></svg>}
          {dir === 'down' && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="18 14 12 20 6 14"/><line x1="12" y1="5" x2="12" y2="20"/></svg>}
          {delta}
        </span>
        <span>{meta}</span>
      </div>
    </div>
  );
}

Object.assign(window, { Trafego });
