// page-header.jsx — Reusable AUDIS page header
// Mirrors the production AudisPageHeader pattern:
//   icon circle (left) + (eyebrow + title + subtitle stack) ... actions (right)
//
// Usage:
//   <PageHeader
//     icon={<svg .../>}
//     eyebrow="MARKETING · ROTEIROS"
//     title="Conteúdo"
//     subtitle="Mesa de roteiros · AUDIS OS"
//     actions={<>
//       <button className="btn btn-secondary">Secundário</button>
//       <button className="btn btn-primary">Primário</button>
//     </>}
//   />

function PageHeader({ icon, eyebrow, title, subtitle, actions, iconVariant }) {
  return (
    <div className="page-header">
      <div className="page-header-lead">
        {icon && (
          <div className={`page-icon ${iconVariant === 'soft' ? 'is-soft' : ''}`}>
            {icon}
          </div>
        )}
        <div className="page-title-group">
          {eyebrow && <div className="page-eyebrow"><span>{eyebrow}</span></div>}
          <h1 className="page-title">{title}</h1>
          {subtitle && <p className="page-sub">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </div>
  );
}

Object.assign(window, { PageHeader });
