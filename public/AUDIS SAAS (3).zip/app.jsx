// app.jsx — Root + roteamento entre views

const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "typography": "audis",
  "density": "regular",
  "cards": "bordered",
  "theme": "light",
  "sidebarMode": "hover"
}/*EDITMODE-END*/;

const NAV_LABELS = {
  inicio:       { eyebrow: 'Operação',  current: 'Cockpit' },
  agenda:       { eyebrow: 'Operação',  current: 'Agenda' },
  operacoes:    { eyebrow: 'Operação',  current: 'Operações' },
  funil:        { eyebrow: 'Operação',  current: 'Funil' },
  estoque:      { eyebrow: 'Operação',  current: 'Estoque' },
  conteudo:     { eyebrow: 'Marketing', current: 'Conteúdo' },
  trafego:      { eyebrow: 'Marketing', current: 'Tráfego' },
  social:       { eyebrow: 'Marketing', current: 'Social' },
  pessoas:      { eyebrow: 'Clientes',  current: 'Pessoas' },
  solicitacoes: { eyebrow: 'Clientes',  current: 'Solicitações' },
  entregas:     { eyebrow: 'Clientes',  current: 'Entregas' },
  projetos:     { eyebrow: 'Clientes',  current: 'Projetos' },
  brandkit:     { eyebrow: 'Clientes',  current: 'Brand Kit' },
  financeiro:   { eyebrow: 'Sistema',   current: 'Financeiro' },
  equipe:       { eyebrow: 'Sistema',   current: 'Equipe' },
  aprendizado:  { eyebrow: 'Sistema',   current: 'Aprendizado' },
};

const VIEWS_BUILT = ['inicio','agenda','trafego','financeiro','pessoas','brandkit','operacoes','funil','solicitacoes','entregas','projetos','conteudo','social','aprendizado'];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [sidebarMode, setSidebarMode] = useState(t.sidebarMode || 'hover');
  const [activeNav, setActiveNav] = useState('inicio');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notifsOpen, setNotifsOpen] = useState(false);
  const [unread, setUnread] = useState(3);
  const [toast, setToast] = useState(null);
  const [clientMode, setClientMode] = useState(false);

  useEffect(() => {
    const r = document.documentElement;
    r.dataset.type = t.typography;
    r.dataset.density = t.density;
    r.dataset.cards = t.cards;
    r.dataset.theme = t.theme;
  }, [t]);

  useEffect(() => {
    setTweak('sidebarMode', sidebarMode);
    try { localStorage.setItem('audis_sidebar_mode', sidebarMode); } catch (e) {}
  }, [sidebarMode]);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        document.querySelector('.search input')?.focus();
      }
      if (e.key === 'n' && !drawerOpen &&
          document.activeElement?.tagName !== 'INPUT' &&
          document.activeElement?.tagName !== 'TEXTAREA') {
        e.preventDefault();
        setDrawerOpen(true);
      }
      if (e.key === 'Escape') {
        setDrawerOpen(false);
        setNotifsOpen(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [drawerOpen]);

  useEffect(() => {
    if (!notifsOpen) return;
    const onClick = (e) => {
      if (!e.target.closest('.popover') && !e.target.closest('.icon-btn')) {
        setNotifsOpen(false);
      }
    };
    setTimeout(() => window.addEventListener('click', onClick), 0);
    return () => window.removeEventListener('click', onClick);
  }, [notifsOpen]);

  const handleNav = (id) => {
    setActiveNav(id);
    if (!VIEWS_BUILT.includes(id)) {
      const label = NAV_LABELS[id]?.current || id;
      setToast({ msg: `"${label}" — próxima view a ser construída`, k: Date.now() });
    }
  };

  const handleCreateItem = (data) => {
    setDrawerOpen(false);
    const kindLabel = { tarefa:'Tarefa', reuniao:'Reunião', entrega:'Entrega', call:'Call' }[data.kind] || 'Item';
    setToast({ msg: `${kindLabel} "${data.title}" criada`, k: Date.now() });
  };

  useEffect(() => {
    if (!toast) return;
    const tt = setTimeout(() => setToast(null), 2400);
    return () => clearTimeout(tt);
  }, [toast]);

  // Portal do cliente: render in place of normal shell
  if (clientMode) {
    return (
      <>
        <Portal onExit={() => setClientMode(false)} />
        <TweaksPanel title="AUDIS · Tweaks"><TweaksContent t={t} setTweak={setTweak} /></TweaksPanel>
      </>
    );
  }

  const nav = NAV_LABELS[activeNav] || NAV_LABELS.inicio;

  return (
    <div className={`app-shell sb-${sidebarMode}`}>
      <Topbar
        dark={t.theme === 'dark'}
        onDark={() => setTweak('theme', t.theme === 'dark' ? 'light' : 'dark')}
        onOpenNotifs={(v) => {
          const next = typeof v === 'boolean' ? v : !notifsOpen;
          setNotifsOpen(next);
          if (next) setUnread(0);
        }}
        notifsOpen={notifsOpen}
        unread={unread}
        onOpenDrawer={() => setDrawerOpen(true)}
      />

      <Sidebar
        mode={sidebarMode}
        onModeChange={setSidebarMode}
        active={activeNav}
        onNavigate={handleNav}
      />

      <main className="main">
        {activeNav === 'inicio'       && <Cockpit onOpenDrawer={() => setDrawerOpen(true)} />}
        {activeNav === 'agenda'       && <Agenda onOpenDrawer={() => setDrawerOpen(true)} />}
        {activeNav === 'operacoes'    && <Operacoes />}
        {activeNav === 'funil'        && <Funil />}
        {activeNav === 'trafego'      && <Trafego />}
        {activeNav === 'financeiro'   && <Financeiro />}
        {activeNav === 'pessoas'      && <Pessoas />}
        {activeNav === 'brandkit'     && <BrandKit />}
        {activeNav === 'solicitacoes' && <Solicitacoes />}
        {activeNav === 'entregas'     && <Entregas />}
        {activeNav === 'projetos'     && <Projetos />}
        {activeNav === 'conteudo'     && <Conteudo />}
        {activeNav === 'social'       && <Social />}
        {activeNav === 'aprendizado'  && <Aprendizado />}
        {!VIEWS_BUILT.includes(activeNav) && (
          <SoonView label={nav.current} />
        )}
      </main>

      <QuickAddDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onSubmit={handleCreateItem}
      />

      {toast && (
        <div className="toast-wrap">
          <div key={toast.k} className="toast">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="5 12 10 17 19 7"/></svg>
            <span>{toast.msg}</span>
          </div>
        </div>
      )}

      <TweaksPanel title="AUDIS · Tweaks"><TweaksContent t={t} setTweak={setTweak} /></TweaksPanel>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
function DynamicTopbar({ dark, onDark, onOpenNotifs, notifsOpen, unread, onOpenDrawer, onClientMode, nav }) {
  const I_search = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></svg>;
  const I_plus = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
  const I_bell = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>;
  const I_eye = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
  const I_moon = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>;
  const I_sun = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="20" x2="12" y2="22"/><line x1="4.9" y1="4.9" x2="6.3" y2="6.3"/><line x1="17.7" y1="17.7" x2="19.1" y2="19.1"/><line x1="2" y1="12" x2="4" y2="12"/><line x1="20" y1="12" x2="22" y2="12"/><line x1="4.9" y1="19.1" x2="6.3" y2="17.7"/><line x1="17.7" y1="6.3" x2="19.1" y2="4.9"/></svg>;
  return (
    <header className="topbar">
      <div className="crumb">
        <span>{nav.eyebrow}</span>
        <span className="crumb-sep">/</span>
        <span className="crumb-current">{nav.current}</span>
      </div>

      <div className="search" onClick={(e) => e.currentTarget.querySelector('input').focus()}>
        <span style={{display:'grid',placeItems:'center',width:14,height:14,color:'var(--text-muted)'}}>{I_search}</span>
        <input placeholder="Buscar cliente, tarefa, projeto…" />
        <span className="kbd">⌘K</span>
      </div>

      <button className="btn btn-ghost btn-sm" onClick={onClientMode} title="Ver como cliente">
        {I_eye} <span>Ver como cliente</span>
      </button>

      <button className="btn btn-ghost btn-sm" onClick={onOpenDrawer} title="Nova tarefa">
        {I_plus} <span>Novo</span>
      </button>

      <button className="icon-btn" onClick={onDark} title={dark ? 'Tema claro' : 'Tema escuro'}>
        {dark ? I_sun : I_moon}
      </button>

      <div style={{position:'relative'}}>
        <button className="icon-btn" onClick={onOpenNotifs} title="Notificações">
          {I_bell}
          {unread > 0 && <span className="dot" />}
        </button>
        <NotifsPopover open={notifsOpen} />
      </div>

      <div className="avatar" title="Bruno Mendes">BM</div>
    </header>
  );
}

// ─────────────────────────────────────────────────────────
function SoonView({ label }) {
  return (
    <div className="page-body view-enter">
      <PageHeader
        icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>}
        eyebrow="Em breve"
        title={label}
        subtitle="Próxima da fila · herda a linguagem do Cockpit"
      />
      <div className="card">
        <div className="card-body">
          <div className="empty-view">
            <div className="icon-bg">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width:24,height:24}}><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>
            </div>
            <h3>"{label}" ainda não foi redesenhada</h3>
            <p>Já existe na sidebar como referência. Posso aplicar a mesma linguagem do Cockpit a esta tela quando quiser.</p>
            <button className="btn btn-primary btn-sm" style={{marginTop:8}}>Pedir essa tela →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
function TweaksContent({ t, setTweak }) {
  return (
    <>
      <TweakSection label="Tipografia" />
      <TweakSelect
        label="Família"
        value={t.typography}
        options={[
          { value: 'audis',     label: 'General Sans (padrão AUDIS)' },
          { value: 'geist',     label: 'Geist + Geist Mono' },
          { value: 'cabinet',   label: 'Cabinet Grotesk + Switzer' },
          { value: 'satoshi',   label: 'Satoshi' },
          { value: 'clash',     label: 'Clash Grotesk + Switzer' },
          { value: 'bricolage', label: 'Bricolage + DM Sans' },
          { value: 'outfit',    label: 'Outfit' },
          { value: 'onest',     label: 'Onest' },
          { value: 'sora',      label: 'Sora + Plus Jakarta' },
          { value: 'manrope',   label: 'Manrope' },
          { value: 'classic',   label: 'Helvetica Neue' },
        ]}
        onChange={(v) => setTweak('typography', v)}
      />

      <TweakSection label="Estilo de cards" />
      <TweakRadio
        label="Visual"
        value={t.cards}
        options={[
          { value: 'flat',     label: 'Flat' },
          { value: 'bordered', label: 'Borda' },
          { value: 'shadowed', label: 'Sombra' },
        ]}
        onChange={(v) => setTweak('cards', v)}
      />

      <TweakSection label="Densidade" />
      <TweakRadio
        label="Espaçamento"
        value={t.density}
        options={[
          { value: 'compact', label: 'Compact' },
          { value: 'regular', label: 'Regular' },
          { value: 'comfy',   label: 'Comfy' },
        ]}
        onChange={(v) => setTweak('density', v)}
      />

      <TweakSection label="Tema" />
      <TweakRadio
        label="Modo"
        value={t.theme}
        options={[
          { value: 'light', label: 'Claro' },
          { value: 'dark',  label: 'Escuro' },
        ]}
        onChange={(v) => setTweak('theme', v)}
      />
      <TweakSection label="Sidebar" />
      <TweakRadio
        label="Modo"
        value={t.sidebarMode || 'hover'}
        options={[
          { value: 'expanded',  label: 'Aberta' },
          { value: 'collapsed', label: 'Recolhida' },
          { value: 'hover',     label: 'Auto-hover' },
        ]}
        onChange={(v) => setTweak('sidebarMode', v)}
      />
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
